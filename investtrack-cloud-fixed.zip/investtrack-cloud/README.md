# InvestTrack Cloud

Cloud-Based Virtual Stock Portfolio Management System for the Indian market (NSE / BSE).
A B.Tech Cloud Computing mini project.

> **All stock prices, index levels and company ratios are sample DEMO DATA.**
> They are not live NSE/BSE quotes. No real trading takes place and no money is involved.

## Stack

React 18 · TypeScript · Tailwind CSS · Recharts · Lucide icons · Vite · React Router (HashRouter)

## Run it

```bash
npm install
npm run dev            # development server
npm run build          # type-check + production build in dist/
npm run build:single   # one self-contained HTML file in dist-single/index.html
```

`dist-single/index.html` opens directly in a browser with no server.

## What is inside

| Page | Route | Highlights |
|---|---|---|
| Landing | `#/` | Intro, features, login / create account, demo access, cloud roadmap |
| Dashboard | `#/app` | Invested, current value, total P/L, daily change, performance chart, allocation donut, top holdings, NIFTY 50 and SENSEX (demo) |
| Stock Explorer | `#/app/explorer` | 10 sample companies, search, sector filters, sorting, detail drawer with price chart |
| My Portfolio | `#/app/portfolio` | Record virtual buys and sells, weighted average price, current value, P/L |
| Watchlist | `#/app/watchlist` | Add and remove stocks, live-updating demo prices |
| Transactions | `#/app/transactions` | Ledger with filters and CSV export |
| Analytics | `#/app/analytics` | Allocation by stock or sector, stock-wise returns, P/L chart, historical value, best and weakest performers |
| Profile & Settings | `#/app/settings` | Profile form, preferences, starting capital, data reset, logout |

Try **Simulate demo market move** in the top bar to nudge the demo prices and watch every metric recalculate.

## How the numbers work

- Average price uses the **weighted-average cost** method.
- Selling realises `(sale price - average price) x quantity`; the average price is unchanged for the remaining shares.
- Virtual cash = starting capital - purchases + sales.
- Orders are validated by replaying the whole ledger, so back-dated trades cannot create negative holdings or negative cash.
- Historical portfolio value replays transactions day by day and values holdings with the demo price history.

## Code layout (AWS-ready)

```
src/
  services/
    types.ts        service contracts (Auth, Portfolio, Market)
    index.ts        the single place that selects the backend
    local/          current localStorage implementations
  store/            React context that talks only to the service interfaces
  lib/              pure logic: calculations, validation, formatting, demo history
  data/             demo stocks and sample portfolio
  components/       reusable UI and charts
  pages/            the eight screens
docs/AWS_INTEGRATION.md   planned Cognito / API Gateway / Lambda / DynamoDB mapping
```

**No AWS services are connected and none are faked.** To go live, implement the interfaces in
`src/services/types.ts` against Cognito and API Gateway/Lambda/DynamoDB and switch `src/services/index.ts`.
See `docs/AWS_INTEGRATION.md` for tables and API routes.

## Notes

- Local accounts are for demonstration only and are not secure authentication.
- Data is stored per account in the browser's `localStorage`; clearing site data removes it.
- Fonts load from Google Fonts when online and fall back to system fonts offline.
