import { localAuth } from './local/auth';
import { localMarket } from './local/market';
import { localPortfolio } from './local/portfolio';
import type { Services } from './types';

/**
 * Single switch point for the backend.
 *
 * Today: browser localStorage (works offline, perfect for a classroom demo).
 * Later: build `awsServices` (Cognito / API Gateway + Lambda / DynamoDB) in
 * ./aws/ implementing the same interfaces from ./types.ts and select it here,
 * for example with `import.meta.env.VITE_BACKEND === 'aws'`.
 * Nothing in src/pages or src/components needs to change.
 */
export const services: Services = {
  auth: localAuth,
  portfolio: localPortfolio,
  market: localMarket,
  backend: 'local-storage',
};

export { ServiceError } from './types';
