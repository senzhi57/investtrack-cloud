/**
 * Service contracts for InvestTrack Cloud.
 *
 * The UI only ever talks to these interfaces (via `services` in ./index.ts).
 * Today they are implemented with browser localStorage (./local/*).
 * Later, AWS-backed implementations can be dropped in without touching any page:
 *
 *   AuthService       -> Amazon Cognito (User Pool + hosted UI / Amplify Auth)
 *   PortfolioService  -> Amazon API Gateway -> AWS Lambda -> Amazon DynamoDB
 *   MarketService     -> Lambda that serves demo or licensed market data
 *
 * See docs/AWS_INTEGRATION.md for the planned table design and API routes.
 * Every method is async on purpose, because network calls will be async.
 */
import type {
  OrderInput,
  Preferences,
  QuoteMap,
  SessionUser,
  Transaction,
  UserData,
  UserProfile,
} from '../types';

export class ServiceError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

export interface AuthService {
  getSession(): Promise<SessionUser | null>;
  login(email: string, password: string): Promise<SessionUser>;
  register(name: string, email: string, password: string): Promise<SessionUser>;
  loginDemo(): Promise<SessionUser>;
  logout(): Promise<void>;
}

export interface PortfolioService {
  load(user: SessionUser): Promise<UserData>;
  addTransaction(userId: string, order: OrderInput): Promise<Transaction>;
  addToWatchlist(userId: string, symbol: string): Promise<string[]>;
  removeFromWatchlist(userId: string, symbol: string): Promise<string[]>;
  updateProfile(userId: string, profile: UserProfile): Promise<UserProfile>;
  updatePreferences(userId: string, prefs: Preferences): Promise<Preferences>;
  /** Replace the account data with the sample portfolio or an empty one. */
  reset(user: SessionUser, mode: 'sample' | 'empty', startingCapital?: number): Promise<UserData>;
}

export interface MarketService {
  /** DEMO quotes. Never live NSE/BSE data. */
  getQuotes(): Promise<QuoteMap>;
  /** Moves the demo prices randomly to illustrate how metrics react. */
  simulateTick(): Promise<QuoteMap>;
  resetQuotes(): Promise<QuoteMap>;
}

export interface Services {
  auth: AuthService;
  portfolio: PortfolioService;
  market: MarketService;
  /** Human-readable name of the active backend, shown in Settings. */
  backend: 'local-storage' | 'aws';
}
