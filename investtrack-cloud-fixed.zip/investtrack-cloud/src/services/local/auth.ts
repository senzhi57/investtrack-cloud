import type { SessionUser } from '../../types';
import { ServiceError, type AuthService } from '../types';
import { KEYS, storage } from './storage';

/**
 * Local demo authentication.
 * This is NOT secure authentication. It exists only so the UI flow can be
 * demonstrated offline. Replace with Amazon Cognito in the AWS adapter.
 */
interface StoredUser {
  id: string;
  name: string;
  email: string;
  passHash: string;
  createdAt: string;
}

async function hash(text: string): Promise<string> {
  try {
    if (typeof crypto !== 'undefined' && crypto.subtle) {
      const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('investtrack:' + text));
      return Array.from(new Uint8Array(buf))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    }
  } catch {
    /* fall through */
  }
  let h = 5381;
  for (let i = 0; i < text.length; i++) h = ((h << 5) + h + text.charCodeAt(i)) | 0;
  return 'x' + (h >>> 0).toString(16);
}

const DEMO_USER: SessionUser = {
  id: 'demo',
  name: 'Demo Investor',
  email: 'demo@investtrack.cloud',
  isDemo: true,
};

const toSession = (u: StoredUser): SessionUser => ({ id: u.id, name: u.name, email: u.email, isDemo: false });

export const localAuth: AuthService = {
  async getSession() {
    return storage.get<SessionUser | null>(KEYS.session, null);
  },

  async login(email, password) {
    const users = storage.get<StoredUser[]>(KEYS.users, []);
    const user = users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
    if (!user) throw new ServiceError('USER_NOT_FOUND', 'No account found for this email. Create an account or use the demo.');
    if (user.passHash !== (await hash(password))) throw new ServiceError('BAD_PASSWORD', 'Incorrect password. Try again.');
    const session = toSession(user);
    storage.set(KEYS.session, session);
    return session;
  },

  async register(name, email, password) {
    const users = storage.get<StoredUser[]>(KEYS.users, []);
    const normalized = email.trim().toLowerCase();
    if (normalized === DEMO_USER.email || users.some((u) => u.email.toLowerCase() === normalized)) {
      throw new ServiceError('EMAIL_EXISTS', 'An account with this email already exists. Log in instead.');
    }
    const user: StoredUser = {
      id: 'u_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      name: name.trim(),
      email: normalized,
      passHash: await hash(password),
      createdAt: new Date().toISOString(),
    };
    storage.set(KEYS.users, [...users, user]);
    const session = toSession(user);
    storage.set(KEYS.session, session);
    return session;
  },

  async loginDemo() {
    storage.set(KEYS.session, DEMO_USER);
    return DEMO_USER;
  },

  async logout() {
    storage.remove(KEYS.session);
  },
};
