import { STOCKS } from '../../data/stocks';
import { roundTo, todayISO } from '../../lib/format';
import type { QuoteMap } from '../../types';
import type { MarketService } from '../types';
import { KEYS, storage } from './storage';

/**
 * DEMO market data source. Prices come from src/data/stocks.ts and the
 * optional "simulate" button. These are never live NSE/BSE quotes.
 */
interface StoredQuotes {
  asOf: string;
  quotes: QuoteMap;
}

function baseQuotes(): QuoteMap {
  return Object.fromEntries(
    STOCKS.map((s) => [s.symbol, { symbol: s.symbol, price: s.basePrice, prevClose: s.basePrevClose, isDemo: true as const }]),
  );
}

function load(): QuoteMap {
  const stored = storage.get<StoredQuotes | null>(KEYS.quotes, null);
  // A new calendar day starts from the base demo prices again.
  if (stored && stored.asOf === todayISO() && Object.keys(stored.quotes).length === STOCKS.length) return stored.quotes;
  const fresh = baseQuotes();
  storage.set(KEYS.quotes, { asOf: todayISO(), quotes: fresh });
  return fresh;
}

export const localMarket: MarketService = {
  async getQuotes() {
    return load();
  },

  async simulateTick() {
    const current = load();
    const next: QuoteMap = {};
    for (const [sym, q] of Object.entries(current)) {
      const move = (Math.random() - 0.5) * 0.03; // +/-1.5%
      next[sym] = { ...q, price: roundTo(Math.max(1, q.price * (1 + move))) };
    }
    storage.set(KEYS.quotes, { asOf: todayISO(), quotes: next });
    return next;
  },

  async resetQuotes() {
    const fresh = baseQuotes();
    storage.set(KEYS.quotes, { asOf: todayISO(), quotes: fresh });
    return fresh;
  },
};
