import { buildEmptyData, buildSampleData } from '../../data/sample';
import { validateOrder } from '../../lib/calc';
import { uid } from '../../lib/format';
import type { OrderInput, Preferences, SessionUser, Transaction, UserData, UserProfile } from '../../types';
import { ServiceError, type PortfolioService } from '../types';
import { KEYS, storage } from './storage';

function read(userId: string): UserData | null {
  return storage.get<UserData | null>(KEYS.data(userId), null);
}

function write(userId: string, data: UserData) {
  storage.set(KEYS.data(userId), data);
}

function requireData(userId: string): UserData {
  const d = read(userId);
  if (!d) throw new ServiceError('NO_DATA', 'Account data was not found. Log in again.');
  return d;
}

export const localPortfolio: PortfolioService = {
  async load(user: SessionUser) {
    const existing = read(user.id);
    if (existing) return existing;
    // First visit: the demo account gets sample data, new accounts start empty.
    const fresh = user.isDemo ? buildSampleData(user) : buildEmptyData(user);
    write(user.id, fresh);
    return fresh;
  },

  async addTransaction(userId: string, order: OrderInput) {
    const data = requireData(userId);
    // Re-validate at the "server" boundary. A Lambda must do the same.
    const check = validateOrder(order, data.transactions, data.preferences.startingCapital);
    if (!check.ok) {
      const msg = Object.values(check.errors)[0] ?? 'Order rejected.';
      throw new ServiceError('INVALID_ORDER', msg);
    }
    const txn: Transaction = {
      id: uid('txn'),
      userId,
      symbol: order.symbol,
      side: order.side,
      exchange: order.exchange,
      quantity: Number(order.quantity),
      price: Number(order.price),
      date: order.date,
      createdAt: new Date().toISOString(),
    };
    write(userId, { ...data, transactions: [...data.transactions, txn] });
    return txn;
  },

  async addToWatchlist(userId: string, symbol: string) {
    const data = requireData(userId);
    if (data.watchlist.includes(symbol)) return data.watchlist;
    const watchlist = [...data.watchlist, symbol];
    write(userId, { ...data, watchlist });
    return watchlist;
  },

  async removeFromWatchlist(userId: string, symbol: string) {
    const data = requireData(userId);
    const watchlist = data.watchlist.filter((s) => s !== symbol);
    write(userId, { ...data, watchlist });
    return watchlist;
  },

  async updateProfile(userId: string, profile: UserProfile) {
    const data = requireData(userId);
    write(userId, { ...data, profile });
    return profile;
  },

  async updatePreferences(userId: string, prefs: Preferences) {
    const data = requireData(userId);
    write(userId, { ...data, preferences: prefs });
    return prefs;
  },

  async reset(user: SessionUser, mode: 'sample' | 'empty', startingCapital?: number) {
    const prev = read(user.id);
    const capital = startingCapital ?? prev?.preferences.startingCapital;
    const fresh = mode === 'sample' ? buildSampleData(user, capital) : buildEmptyData(user, capital);
    if (prev) {
      fresh.profile = prev.profile;
      fresh.preferences = { ...prev.preferences, startingCapital: capital ?? prev.preferences.startingCapital };
    }
    write(user.id, fresh);
    return fresh;
  },
};
