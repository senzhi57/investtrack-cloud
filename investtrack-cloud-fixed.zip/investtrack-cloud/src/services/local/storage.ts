/** localStorage wrapper that never throws (private mode, quota, disabled storage). */
const memory = new Map<string, string>();

function hasLocalStorage(): boolean {
  try {
    const k = '__it_test__';
    window.localStorage.setItem(k, '1');
    window.localStorage.removeItem(k);
    return true;
  } catch {
    return false;
  }
}

const usable = typeof window !== 'undefined' && hasLocalStorage();

export const storage = {
  get<T>(key: string, fallback: T): T {
    try {
      const raw = usable ? window.localStorage.getItem(key) : memory.get(key) ?? null;
      return raw ? (JSON.parse(raw) as T) : fallback;
    } catch {
      return fallback;
    }
  },
  set<T>(key: string, value: T): void {
    const raw = JSON.stringify(value);
    try {
      if (usable) window.localStorage.setItem(key, raw);
      else memory.set(key, raw);
    } catch {
      memory.set(key, raw);
    }
  },
  remove(key: string): void {
    try {
      if (usable) window.localStorage.removeItem(key);
    } catch {
      /* ignore */
    }
    memory.delete(key);
  },
  persistent: usable,
};

export const KEYS = {
  users: 'investtrack:users:v1',
  session: 'investtrack:session:v1',
  data: (userId: string) => `investtrack:data:v1:${userId}`,
  quotes: 'investtrack:quotes:v1',
};
