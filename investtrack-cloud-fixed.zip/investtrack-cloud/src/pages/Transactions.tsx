import { Download, History, Plus, Search, SearchX } from 'lucide-react';
import { useMemo, useState } from 'react';
import { useOverlays } from '../components/Overlays';
import { cx, EmptyState, PageHeader, Panel } from '../components/ui';
import { STOCK_MAP } from '../data/stocks';
import { formatDate, formatInt, formatINR } from '../lib/format';
import { useApp } from '../store/AppContext';

type Filter = 'ALL' | 'BUY' | 'SELL';

export default function Transactions() {
  const { data, money, notify, resetData } = useApp();
  const { openTrade } = useOverlays();
  const [filter, setFilter] = useState<Filter>('ALL');
  const [query, setQuery] = useState('');

  const all = useMemo(
    () => [...(data?.transactions ?? [])].sort((a, b) => (a.date === b.date ? (a.createdAt < b.createdAt ? 1 : -1) : a.date < b.date ? 1 : -1)),
    [data],
  );
  const rows = all.filter((t) => (filter === 'ALL' || t.side === filter) && (!query.trim() || t.symbol.toLowerCase().includes(query.trim().toLowerCase())));

  const bought = all.filter((t) => t.side === 'BUY').reduce((s, t) => s + t.quantity * t.price, 0);
  const sold = all.filter((t) => t.side === 'SELL').reduce((s, t) => s + t.quantity * t.price, 0);

  const exportCsv = () => {
    const header = 'Date,Symbol,Exchange,Type,Quantity,Price (INR),Value (INR)\n';
    const body = rows.map((t) => [t.date, t.symbol, t.exchange, t.side, t.quantity, t.price.toFixed(2), (t.quantity * t.price).toFixed(2)].join(',')).join('\n');
    const blob = new Blob([header + body], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'investtrack-transactions.csv';
    a.click();
    URL.revokeObjectURL(url);
    notify('success', `Exported ${rows.length} transaction${rows.length === 1 ? '' : 's'} to CSV`);
  };

  return (
    <>
      <PageHeader
        title="Transaction History"
        description="Every virtual buy and sell you have recorded, newest first."
        actions={
          <>
            <button className="btn-ghost" onClick={exportCsv} disabled={rows.length === 0}>
              <Download size={16} aria-hidden="true" /> Export CSV
            </button>
            <button className="btn-primary" onClick={() => openTrade()}>
              <Plus size={16} aria-hidden="true" /> New trade
            </button>
          </>
        }
      />

      {all.length === 0 ? (
        <Panel>
          <EmptyState
            icon={<History size={22} />}
            title="No transactions yet"
            description="Your virtual buys and sells will be listed here with date, symbol, quantity and price."
            action={
              <>
                <button className="btn-primary" onClick={() => openTrade()}>
                  <Plus size={16} /> Record a purchase
                </button>
                <button className="btn-ghost" onClick={() => resetData('sample')}>
                  Load sample portfolio
                </button>
              </>
            }
          />
        </Panel>
      ) : (
        <>
          <div className="mb-5 grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Panel className="!p-4">
              <div className="text-xs text-slate-400">Transactions</div>
              <div className="num mt-1 font-display text-xl font-semibold text-white">{all.length}</div>
            </Panel>
            <Panel className="!p-4">
              <div className="text-xs text-slate-400">Total bought</div>
              <div className="num mt-1 font-display text-xl font-semibold text-white">{money(bought)}</div>
            </Panel>
            <Panel className="!p-4">
              <div className="text-xs text-slate-400">Total sold</div>
              <div className="num mt-1 font-display text-xl font-semibold text-white">{money(sold)}</div>
            </Panel>
          </div>

          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" aria-hidden="true" />
              <input className="input !pl-10" placeholder="Filter by symbol" aria-label="Filter by symbol" value={query} onChange={(e) => setQuery(e.target.value)} />
            </div>
            <div className="inline-flex rounded-xl border border-white/10 bg-navy-950/60 p-0.5" role="group" aria-label="Filter by type">
              {(['ALL', 'BUY', 'SELL'] as Filter[]).map((f) => (
                <button
                  key={f}
                  aria-pressed={filter === f}
                  onClick={() => setFilter(f)}
                  className={cx('rounded-lg px-4 py-2 text-xs font-semibold transition', filter === f ? 'bg-emerald-500 text-navy-950' : 'text-slate-400 hover:text-white')}
                >
                  {f === 'ALL' ? 'All' : f === 'BUY' ? 'Buys' : 'Sells'}
                </button>
              ))}
            </div>
          </div>

          {rows.length === 0 ? (
            <Panel>
              <EmptyState icon={<SearchX size={22} />} title="No matching transactions" description="Try a different symbol or switch the type filter back to All." />
            </Panel>
          ) : (
            <Panel pad={false}>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[720px]">
                  <thead>
                    <tr className="border-b border-white/[0.06]">
                      <th className="th">Date</th>
                      <th className="th">Stock</th>
                      <th className="th">Type</th>
                      <th className="th">Exchange</th>
                      <th className="th text-right">Quantity</th>
                      <th className="th text-right">Price</th>
                      <th className="th text-right">Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((t) => (
                      <tr key={t.id} className="border-b border-white/[0.04] transition last:border-0 hover:bg-white/[0.03]">
                        <td className="td whitespace-nowrap text-slate-300">{formatDate(t.date)}</td>
                        <td className="td">
                          <div className="font-semibold text-white">{t.symbol}</div>
                          <div className="text-xs text-slate-500">{STOCK_MAP[t.symbol]?.name}</div>
                        </td>
                        <td className="td">
                          <span className={cx('rounded-md px-2 py-0.5 text-xs font-bold', t.side === 'BUY' ? 'bg-emerald-500/15 text-emerald-300' : 'bg-loss-500/15 text-loss-400')}>{t.side === 'BUY' ? 'Buy' : 'Sell'}</span>
                        </td>
                        <td className="td text-slate-300">{t.exchange}</td>
                        <td className="td num text-right text-white">{formatInt(t.quantity)}</td>
                        <td className="td num text-right text-slate-200">{formatINR(t.price)}</td>
                        <td className="td num text-right font-medium text-white">{formatINR(t.quantity * t.price)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Panel>
          )}
        </>
      )}
    </>
  );
}
