import { BarChart3, Plus, Sparkles, Trophy, TrendingDown } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, Cell, LabelList, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import AllocationChart from '../components/AllocationChart';
import { useOverlays } from '../components/Overlays';
import PerformanceChart from '../components/PerformanceChart';
import { Change, ChartTooltip, EmptyState, PageHeader, Panel, PanelHeader } from '../components/ui';
import { formatNumber, formatPct, toneClass } from '../lib/format';
import { useApp } from '../store/AppContext';

const GAIN = '#34d399';
const LOSS = '#fb7185';

export default function Analytics() {
  const { summary, money, resetData } = useApp();
  const { openTrade } = useOverlays();
  const { holdings } = summary;

  if (holdings.length === 0) {
    return (
      <>
        <PageHeader title="Analytics" description="Allocation, returns and history for your virtual portfolio." />
        <Panel>
          <EmptyState
            icon={<BarChart3 size={22} />}
            title="Nothing to analyse yet"
            description="Analytics need at least one holding. Record a purchase or load the sample portfolio."
            action={
              <>
                <button className="btn-primary" onClick={() => openTrade(undefined, 'BUY')}>
                  <Plus size={16} /> Record a purchase
                </button>
                <button className="btn-ghost" onClick={() => resetData('sample')}>
                  <Sparkles size={16} /> Load sample portfolio
                </button>
              </>
            }
          />
        </Panel>
      </>
    );
  }

  const byReturn = [...holdings].sort((a, b) => b.pnlPct - a.pnlPct);
  const best = byReturn[0];
  const worst = byReturn[byReturn.length - 1];
  const returns = byReturn.map((h) => ({ symbol: h.symbol, pct: Number(h.pnlPct.toFixed(2)) }));
  const pnl = [...holdings].sort((a, b) => b.pnl - a.pnl).map((h) => ({ symbol: h.symbol, pnl: Math.round(h.pnl) }));
  const chartH = Math.max(260, holdings.length * 38);

  return (
    <>
      <PageHeader title="Analytics" description="How your virtual portfolio is split, which stocks drive the result, and how its value has moved. Sample (DEMO) prices throughout." />

      <div className="mb-6 grid grid-cols-1 gap-4 md:grid-cols-2">
        {[
          { label: 'Best performer', h: best, icon: <Trophy size={18} className="text-emerald-400" /> },
          { label: 'Weakest performer', h: worst, icon: <TrendingDown size={18} className="text-loss-400" /> },
        ].map(({ label, h, icon }) => (
          <Panel key={label}>
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-[13px] font-medium">{label}</span>
              {icon}
            </div>
            <div className="mt-3 flex flex-wrap items-end justify-between gap-3">
              <div>
                <div className="font-display text-2xl font-semibold text-white">{h.symbol}</div>
                <div className="text-xs text-slate-500">{h.name}</div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-semibold">
                  <Change value={h.pnlPct} />
                </div>
                <div className={`num text-xs font-medium ${toneClass(h.pnl)}`}>{money(h.pnl, { sign: true })}</div>
              </div>
            </div>
          </Panel>
        ))}
      </div>

      <div className="space-y-6">
        <Panel>
          <PanelHeader title="Historical portfolio value" subtitle="Rebuilt day by day from your transactions and sample price history" />
          <PerformanceChart height={320} initial="1Y" />
        </Panel>

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
          <Panel>
            <PanelHeader title="Portfolio allocation" subtitle="Switch between stock and sector view" />
            <AllocationChart height={230} />
          </Panel>

          <Panel>
            <PanelHeader title="Stock-wise returns" subtitle="Unrealised return on cost, in percent" />
            <div style={{ height: chartH }}>
              <ResponsiveContainer>
                <BarChart data={returns} layout="vertical" margin={{ top: 0, right: 56, left: 0, bottom: 0 }}>
                  <CartesianGrid stroke="rgba(255,255,255,0.05)" horizontal={false} />
                  <XAxis
                    type="number"
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(v) => `${v}%`}
                    domain={[(min: number) => Math.min(-8, Math.floor(min - 8)), (max: number) => Math.ceil(max + 8)]}
                  />
                  <YAxis type="category" dataKey="symbol" tickLine={false} axisLine={false} width={104} tick={{ fill: '#cbd5e1', fontSize: 12 }} />
                  <Tooltip cursor={{ fill: 'rgba(255,255,255,0.04)' }} content={<ChartTooltip format={(v) => formatPct(v)} />} />
                  <Bar dataKey="pct" name="Return" radius={[0, 4, 4, 0]} barSize={18} isAnimationActive={false}>
                    {returns.map((r) => (
                      <Cell key={r.symbol} fill={r.pct >= 0 ? GAIN : LOSS} />
                    ))}
                    <LabelList dataKey="pct" position="right" formatter={(v: unknown) => formatPct(Number(v))} style={{ fill: '#cbd5e1', fontSize: 11 }} />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Panel>
        </div>

        <Panel>
          <PanelHeader title="Profit and loss by stock" subtitle="Unrealised profit or loss in rupees" />
          <div className="h-72">
            <ResponsiveContainer>
              <BarChart data={pnl} margin={{ top: 16, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis dataKey="symbol" tickLine={false} axisLine={false} interval={0} tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <YAxis tickLine={false} axisLine={false} width={60} tickFormatter={(v: number) => (Math.abs(v) >= 1000 ? `${formatNumber(v / 1000, 0)}K` : String(v))} />
                <Tooltip cursor={{ fill: 'rgba(255,255,255,0.04)' }} content={<ChartTooltip format={(v) => money(v, { sign: true, forceFull: true })} />} />
                <Bar dataKey="pnl" name="Profit / loss" radius={[4, 4, 0, 0]} maxBarSize={34} isAnimationActive={false}>
                  {pnl.map((r) => (
                    <Cell key={r.symbol} fill={r.pnl >= 0 ? GAIN : LOSS} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 flex items-center gap-5 text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ background: GAIN }} /> Profit
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ background: LOSS }} /> Loss
            </span>
          </div>
        </Panel>
      </div>
    </>
  );
}
