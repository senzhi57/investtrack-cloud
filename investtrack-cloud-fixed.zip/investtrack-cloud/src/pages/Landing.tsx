import {
  ArrowRight,
  BarChart3,
  Cloud,
  Database,
  Eye,
  History,
  KeyRound,
  LineChart,
  ServerCog,
  ShieldCheck,
  Wallet,
  Waypoints,
} from 'lucide-react';
import { useState } from 'react';
import { Area, AreaChart, ResponsiveContainer } from 'recharts';
import { useNavigate } from 'react-router-dom';
import { cx, DemoBadge, ErrorBanner, Field, Logo } from '../components/ui';
import { DEMO_NOTICE } from '../data/stocks';
import { useApp } from '../store/AppContext';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const FEATURES = [
  { icon: Wallet, title: 'Virtual portfolio', text: 'Record hypothetical buys and sells with quantity, price and date. Average price and P/L are worked out for you.' },
  { icon: LineChart, title: 'Stock explorer', text: 'Search ten sample NSE and BSE companies, filter by sector and open a detail view with a price chart.' },
  { icon: BarChart3, title: 'Analytics', text: 'Allocation, stock-wise returns, profit and loss, and best and weakest performers in one place.' },
  { icon: History, title: 'Transaction history', text: 'A dated ledger of every virtual order, filterable and exportable to CSV.' },
  { icon: Eye, title: 'Watchlist', text: 'Save stocks you want to follow and open a virtual trade from the list when you are ready.' },
  { icon: ShieldCheck, title: 'Safe by design', text: 'No real money, no broker link and no live quotes. Every price is labelled DEMO DATA.' },
];

/**
 * The app uses HashRouter, so a plain <a href="#features"> would be read as the route
 * "/features" (and redirected to "/"). Scroll to the section instead of changing the hash.
 */
function scrollToSection(e: React.MouseEvent, id: string) {
  e.preventDefault();
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

const PREVIEW = Array.from({ length: 40 }, (_, i) => ({ i, v: 100 + i * 1.1 + Math.sin(i / 3) * 6 + Math.cos(i / 7) * 4 }));

function AuthCard() {
  const { login, register, loginDemo } = useApp();
  const navigate = useNavigate();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (mode === 'register' && name.trim().length < 2) errs.name = 'Enter your name (at least 2 characters).';
    if (!EMAIL_RE.test(email.trim())) errs.email = 'Enter a valid email address.';
    if (password.length < 6) errs.password = 'Password must be at least 6 characters.';
    if (mode === 'register' && confirm !== password) errs.confirm = 'Passwords do not match.';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      if (mode === 'login') await login(email, password);
      else await register(name, email, password);
      navigate('/app');
    } catch (err) {
      setErrors({ form: err instanceof Error ? err.message : 'Something went wrong. Try again.' });
    } finally {
      setBusy(false);
    }
  };

  const demo = async () => {
    setBusy(true);
    try {
      await loginDemo();
      navigate('/app');
    } catch (err) {
      setErrors({ form: err instanceof Error ? err.message : 'Could not open the demo. Try again.' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div id="access" className="panel border-white/10 bg-navy-800 p-6 shadow-glow sm:p-7">
      <div className="mb-5 grid grid-cols-2 gap-1 rounded-xl border border-white/10 bg-navy-950/60 p-1" role="tablist">
        {(['login', 'register'] as const).map((m) => (
          <button
            key={m}
            role="tab"
            aria-selected={mode === m}
            onClick={() => {
              setMode(m);
              setErrors({});
            }}
            className={cx('rounded-lg py-2 text-sm font-semibold transition', mode === m ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white')}
          >
            {m === 'login' ? 'Log in' : 'Create account'}
          </button>
        ))}
      </div>

      <form onSubmit={submit} noValidate className="space-y-4">
        {mode === 'register' && (
          <Field label="Full name" htmlFor="a-name" error={errors.name}>
            <input id="a-name" autoComplete="name" className={cx('input', errors.name && 'input-error')} value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
        )}
        <Field label="Email" htmlFor="a-email" error={errors.email}>
          <input id="a-email" type="email" autoComplete="email" placeholder="you@college.edu" className={cx('input', errors.email && 'input-error')} value={email} onChange={(e) => setEmail(e.target.value)} />
        </Field>
        <Field label="Password" htmlFor="a-pass" error={errors.password}>
          <input id="a-pass" type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} className={cx('input', errors.password && 'input-error')} value={password} onChange={(e) => setPassword(e.target.value)} />
        </Field>
        {mode === 'register' && (
          <Field label="Confirm password" htmlFor="a-conf" error={errors.confirm}>
            <input id="a-conf" type="password" autoComplete="new-password" className={cx('input', errors.confirm && 'input-error')} value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          </Field>
        )}
        <ErrorBanner message={errors.form} />
        <button type="submit" disabled={busy} className="btn-primary w-full">
          {mode === 'login' ? 'Log in' : 'Create account'}
        </button>
      </form>

      <div className="my-5 flex items-center gap-3 text-xs text-slate-500">
        <span className="h-px flex-1 bg-white/10" /> or <span className="h-px flex-1 bg-white/10" />
      </div>
      <button onClick={demo} disabled={busy} className="btn-ghost w-full">
        Try the demo with a sample portfolio <ArrowRight size={16} aria-hidden="true" />
      </button>
      <p className="mt-4 text-center text-[11px] leading-relaxed text-slate-500">
        Accounts are stored only in this browser for the demonstration. This is not secure authentication. AWS Cognito is planned, not connected.
      </p>
    </div>
  );
}

export default function Landing() {
  const { user } = useApp();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 sm:px-8">
        <Logo />
        <nav className="flex items-center gap-2" aria-label="Site">
          <a href="#features" onClick={(e) => scrollToSection(e, 'features')} className="hidden rounded-lg px-3 py-2 text-sm text-slate-300 transition hover:text-white sm:block">
            Features
          </a>
          <a href="#cloud" onClick={(e) => scrollToSection(e, 'cloud')} className="hidden rounded-lg px-3 py-2 text-sm text-slate-300 transition hover:text-white sm:block">
            Cloud roadmap
          </a>
          {user ? (
            <button className="btn-primary !py-2" onClick={() => navigate('/app')}>
              Open dashboard
            </button>
          ) : (
            <a href="#access" onClick={(e) => scrollToSection(e, 'access')} className="btn-primary !py-2">
              Log in
            </a>
          )}
        </nav>
      </header>

      <main>
        {/* Hero */}
        <section className="mx-auto grid max-w-7xl items-center gap-12 px-5 pb-16 pt-8 sm:px-8 lg:grid-cols-[1.15fr_0.85fr] lg:pb-24 lg:pt-14">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-1.5 text-xs text-slate-300">
              <Cloud size={14} className="text-emerald-400" aria-hidden="true" />
              Cloud Computing mini project · B.Tech
            </div>
            <h1 className="font-display text-4xl font-semibold leading-[1.1] tracking-tight text-white sm:text-5xl lg:text-[56px]">
              Learn to manage a stock portfolio before you risk a rupee.
            </h1>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-slate-300 sm:text-lg">
              InvestTrack Cloud is a virtual portfolio tracker for Indian NSE and BSE stocks. Record practice trades, watch profit and loss update, and study how your allocation changes.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#access" onClick={(e) => scrollToSection(e, 'access')} className="btn-primary !px-6 !py-3">
                Try the demo <ArrowRight size={16} aria-hidden="true" />
              </a>
              <a href="#features" onClick={(e) => scrollToSection(e, 'features')} className="btn-ghost !px-6 !py-3">
                See what it does
              </a>
            </div>
            <div className="mt-8 flex items-start gap-3 rounded-xl border border-amber-400/20 bg-amber-400/[0.06] p-3.5 text-xs leading-relaxed text-amber-100/90">
              <DemoBadge className="mt-0.5 shrink-0" />
              <span>{DEMO_NOTICE}</span>
            </div>
          </div>
          <AuthCard />
        </section>

        {/* Product preview */}
        <section className="mx-auto max-w-7xl px-5 pb-20 sm:px-8">
          <div className="panel overflow-hidden p-1.5">
            <div className="rounded-xl bg-navy-900/80 p-5 sm:p-7">
              <div className="grid gap-4 sm:grid-cols-3">
                {[
                  ['Current value', '₹5,84,320', 'text-white'],
                  ['Total profit / loss', '+₹41,870', 'text-emerald-400'],
                  ['Virtual cash', '₹4,15,680', 'text-white'],
                ].map(([k, v, c]) => (
                  <div key={k} className="rounded-xl border border-white/[0.06] bg-charcoal-800/70 p-4">
                    <div className="text-xs text-slate-400">{k}</div>
                    <div className={`num mt-2 font-display text-2xl font-semibold ${c}`}>{v}</div>
                  </div>
                ))}
              </div>
              <div className="mt-4 h-40 rounded-xl border border-white/[0.06] bg-charcoal-800/50 p-3">
                <ResponsiveContainer>
                  <AreaChart data={PREVIEW}>
                    <defs>
                      <linearGradient id="lp" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#34d399" stopOpacity={0.35} />
                        <stop offset="100%" stopColor="#34d399" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <Area type="monotone" dataKey="v" stroke="#34d399" strokeWidth={2} fill="url(#lp)" dot={false} isAnimationActive={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <p className="mt-3 text-center text-[11px] text-slate-500">Illustrative preview with sample numbers. Log in to the demo to explore the working app.</p>
            </div>
          </div>
        </section>

        {/* Features */}
        <section id="features" className="mx-auto max-w-7xl scroll-mt-8 px-5 pb-24 sm:px-8">
          <h2 className="max-w-2xl font-display text-3xl font-semibold tracking-tight text-white">Everything you need to practise portfolio management</h2>
          <p className="mt-3 max-w-2xl text-slate-400">Each feature works on your own virtual data, and every number recalculates after each transaction.</p>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map(({ icon: Icon, title, text }) => (
              <div key={title} className="panel p-6 transition hover:border-emerald-500/25">
                <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/[0.12] text-emerald-400">
                  <Icon size={20} aria-hidden="true" />
                </div>
                <h3 className="font-display text-[15px] font-semibold text-white">{title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">{text}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Cloud roadmap */}
        <section id="cloud" className="mx-auto max-w-7xl scroll-mt-8 px-5 pb-24 sm:px-8">
          <div className="panel p-6 sm:p-10">
            <h2 className="font-display text-3xl font-semibold tracking-tight text-white">Built to move to AWS</h2>
            <p className="mt-3 max-w-2xl text-slate-400">
              This version runs in your browser and saves to local storage. The code is split so that cloud services can replace the local ones later without rewriting the screens. None of the services below are connected yet.
            </p>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { icon: KeyRound, name: 'Amazon Cognito', role: 'Sign-up, login and tokens' },
                { icon: Waypoints, name: 'API Gateway', role: 'Secure REST endpoints' },
                { icon: ServerCog, name: 'AWS Lambda', role: 'Order validation and portfolio logic' },
                { icon: Database, name: 'Amazon DynamoDB', role: 'Users, transactions, watchlists' },
              ].map(({ icon: Icon, name, role }) => (
                <div key={name} className="rounded-xl border border-dashed border-white/15 bg-charcoal-800/50 p-5">
                  <Icon size={20} className="text-slate-400" aria-hidden="true" />
                  <div className="mt-3 font-semibold text-white">{name}</div>
                  <div className="mt-1 text-xs text-slate-400">{role}</div>
                  <span className="mt-3 inline-block rounded-md border border-white/10 px-2 py-0.5 text-[11px] text-slate-400">Planned, not connected</span>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/[0.06] px-5 py-8 text-center text-xs leading-relaxed text-slate-500 sm:px-8">
        <Logo size={24} />
        <p className="mx-auto mt-4 max-w-2xl">
          InvestTrack Cloud is an educational project. {DEMO_NOTICE} It is not investment advice and is not affiliated with NSE, BSE or any broker.
        </p>
      </footer>
    </div>
  );
}
