import { Cloud, Database, LogOut, RotateCcw, Save, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { cx, ErrorBanner, Field, Modal, PageHeader, Panel, PanelHeader } from '../components/ui';
import { replay } from '../lib/calc';
import { formatINR } from '../lib/format';
import { services } from '../services';
import { storage } from '../services/local/storage';
import { useApp } from '../store/AppContext';
import type { Preferences, UserProfile } from '../types';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export default function Settings() {
  const { data, user, saveProfile, savePreferences, resetData, resetPrices, logout } = useApp();
  const navigate = useNavigate();

  const [profile, setProfile] = useState<UserProfile | null>(data?.profile ?? null);
  const [profileErr, setProfileErr] = useState<Record<string, string>>({});
  const [prefs, setPrefs] = useState<Preferences | null>(data?.preferences ?? null);
  const [capital, setCapital] = useState(String(data?.preferences.startingCapital ?? ''));
  const [capErr, setCapErr] = useState('');
  const [confirm, setConfirm] = useState<null | 'sample' | 'empty'>(null);

  useEffect(() => {
    if (data) {
      setProfile(data.profile);
      setPrefs(data.preferences);
      setCapital(String(data.preferences.startingCapital));
    }
  }, [data]);

  if (!data || !profile || !prefs || !user) return null;

  const submitProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (profile.name.trim().length < 2) errs.name = 'Enter your full name (at least 2 characters).';
    if (!EMAIL_RE.test(profile.email.trim())) errs.email = 'Enter a valid email address.';
    if (profile.institution.length > 80) errs.institution = 'Keep this under 80 characters.';
    setProfileErr(errs);
    if (Object.keys(errs).length) return;
    await saveProfile({ ...profile, name: profile.name.trim(), email: profile.email.trim() });
  };

  const submitPrefs = async (e: React.FormEvent) => {
    e.preventDefault();
    const cap = Number(capital);
    if (capital.trim() === '' || Number.isNaN(cap)) return setCapErr('Enter the starting virtual capital.');
    if (cap < 10_000) return setCapErr('Starting capital must be at least ₹10,000.');
    if (cap > 100_000_000) return setCapErr('Starting capital cannot exceed ₹10 crore.');
    const minCash = replay(data.transactions, cap).minCash;
    if (minCash < -0.005) {
      return setCapErr(`This amount is too low for your existing trades. You need at least ${formatINR(cap - minCash)}.`);
    }
    setCapErr('');
    await savePreferences({ ...prefs, startingCapital: cap });
  };

  const doLogout = async () => {
    await logout();
    navigate('/');
  };

  const Toggle = ({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) => (
    <button type="button" role="switch" aria-checked={on} aria-label={label} onClick={() => onChange(!on)} className={cx('relative h-6 w-11 rounded-full transition', on ? 'bg-emerald-500' : 'bg-navy-500')}>
      <span className={cx('absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all', on ? 'left-[22px]' : 'left-0.5')} />
    </button>
  );

  return (
    <>
      <PageHeader title="Profile & Settings" description="Manage your profile, display preferences and demo data." />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Panel>
          <PanelHeader title="User profile" subtitle={user.isDemo ? 'You are using the shared demo account.' : 'Stored in this browser for now.'} />
          <form onSubmit={submitProfile} noValidate className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/15 font-display text-xl font-semibold text-emerald-300">{profile.name.charAt(0).toUpperCase() || '?'}</div>
              <div className="text-sm text-slate-400">Your initial appears as your avatar.</div>
            </div>
            <Field label="Full name" htmlFor="p-name" error={profileErr.name}>
              <input id="p-name" className={cx('input', profileErr.name && 'input-error')} value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} />
            </Field>
            <Field label="Email" htmlFor="p-email" error={profileErr.email}>
              <input id="p-email" type="email" className={cx('input', profileErr.email && 'input-error')} value={profile.email} onChange={(e) => setProfile({ ...profile, email: e.target.value })} />
            </Field>
            <Field label="College or organisation" htmlFor="p-inst" error={profileErr.institution}>
              <input id="p-inst" className={cx('input', profileErr.institution && 'input-error')} value={profile.institution} onChange={(e) => setProfile({ ...profile, institution: e.target.value })} />
            </Field>
            <Field label="Experience level" htmlFor="p-type">
              <select id="p-type" className="input" value={profile.investorType} onChange={(e) => setProfile({ ...profile, investorType: e.target.value as UserProfile['investorType'] })}>
                <option>Beginner</option>
                <option>Intermediate</option>
                <option>Advanced</option>
              </select>
            </Field>
            <button className="btn-primary" type="submit">
              <Save size={16} aria-hidden="true" /> Save profile
            </button>
          </form>
        </Panel>

        <Panel>
          <PanelHeader title="Preferences" subtitle="Changes apply across the whole app." />
          <form onSubmit={submitPrefs} noValidate className="space-y-4">
            <Field label="Number display" htmlFor="pf-num" hint="Compact shows ₹12.5 L instead of ₹12,50,000.00 on cards and tables.">
              <select id="pf-num" className="input" value={prefs.numberFormat} onChange={(e) => setPrefs({ ...prefs, numberFormat: e.target.value as Preferences['numberFormat'] })}>
                <option value="full">Full amounts (₹12,50,000.00)</option>
                <option value="compact">Compact (₹12.50 L)</option>
              </select>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Default exchange" htmlFor="pf-ex">
                <select id="pf-ex" className="input" value={prefs.defaultExchange} onChange={(e) => setPrefs({ ...prefs, defaultExchange: e.target.value as Preferences['defaultExchange'] })}>
                  <option>NSE</option>
                  <option>BSE</option>
                </select>
              </Field>
              <Field label="Default chart range" htmlFor="pf-range">
                <select id="pf-range" className="input" value={prefs.defaultRange} onChange={(e) => setPrefs({ ...prefs, defaultRange: e.target.value as Preferences['defaultRange'] })}>
                  <option>1M</option>
                  <option>3M</option>
                  <option>6M</option>
                </select>
              </Field>
            </div>
            <Field label="Starting virtual capital (₹)" htmlFor="pf-cap" error={capErr} hint="Practice money used to calculate your virtual cash balance.">
              <input id="pf-cap" inputMode="numeric" className={cx('input num', capErr && 'input-error')} value={capital} onChange={(e) => setCapital(e.target.value)} />
            </Field>
            <div className="flex items-center justify-between rounded-xl border border-white/[0.06] bg-charcoal-800/60 px-4 py-3">
              <div>
                <div className="text-sm font-medium text-white">Show demo data banner</div>
                <div className="text-xs text-slate-400">The notice under the top bar. The DEMO DATA labels on prices always stay.</div>
              </div>
              <Toggle on={prefs.showDemoBanner} onChange={(v) => setPrefs({ ...prefs, showDemoBanner: v })} label="Show demo data banner" />
            </div>
            <button className="btn-primary" type="submit">
              <Save size={16} aria-hidden="true" /> Save preferences
            </button>
          </form>
        </Panel>

        <Panel>
          <PanelHeader title="Demo data" subtitle="Your data lives in this browser's local storage." />
          <div className="space-y-3">
            <button className="btn-ghost w-full justify-start" onClick={() => setConfirm('sample')}>
              <RotateCcw size={16} aria-hidden="true" /> Reset to the sample portfolio
            </button>
            <button className="btn-ghost w-full justify-start" onClick={resetPrices}>
              <RotateCcw size={16} aria-hidden="true" /> Restore original demo prices
            </button>
            <button className="btn-danger w-full justify-start" onClick={() => setConfirm('empty')}>
              <Trash2 size={16} aria-hidden="true" /> Clear all transactions and watchlist
            </button>
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="Cloud readiness" subtitle="How this build stores data today" />
          <dl className="space-y-3 text-sm">
            <div className="flex items-start gap-3 rounded-xl border border-white/[0.06] bg-charcoal-800/60 p-3.5">
              <Database size={18} className="mt-0.5 shrink-0 text-emerald-400" aria-hidden="true" />
              <div>
                <dt className="font-medium text-white">Active storage: {services.backend === 'local-storage' ? 'Browser local storage' : 'AWS'}</dt>
                <dd className="mt-0.5 text-xs text-slate-400">{storage.persistent ? 'Persistent across refreshes on this device.' : 'Local storage is blocked, so data lasts only until this tab closes.'}</dd>
              </div>
            </div>
            <div className="flex items-start gap-3 rounded-xl border border-white/[0.06] bg-charcoal-800/60 p-3.5">
              <Cloud size={18} className="mt-0.5 shrink-0 text-slate-400" aria-hidden="true" />
              <div>
                <dt className="font-medium text-white">AWS: not connected</dt>
                <dd className="mt-0.5 text-xs text-slate-400">The service layer in src/services is ready for Cognito, API Gateway, Lambda and DynamoDB. See docs/AWS_INTEGRATION.md.</dd>
              </div>
            </div>
          </dl>
        </Panel>
      </div>

      <Panel className="mt-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="font-display text-[15px] font-semibold text-white">Log out</h3>
            <p className="mt-0.5 text-xs text-slate-400">Your portfolio stays saved in this browser. Log back in to continue.</p>
          </div>
          <button className="btn-danger" onClick={doLogout}>
            <LogOut size={16} aria-hidden="true" /> Log out
          </button>
        </div>
      </Panel>

      <Modal open={confirm !== null} onClose={() => setConfirm(null)} title={confirm === 'sample' ? 'Reset to sample portfolio?' : 'Clear all data?'} width="max-w-md">
        <ErrorBanner message={undefined} />
        <p className="text-sm text-slate-300">
          {confirm === 'sample' ? 'This replaces your current transactions and watchlist with the sample portfolio.' : 'This permanently removes every transaction and watchlist entry for this account.'}
        </p>
        <div className="mt-6 flex gap-3">
          <button className="btn-ghost flex-1" onClick={() => setConfirm(null)}>
            Cancel
          </button>
          <button
            className={cx('flex-1', confirm === 'empty' ? 'btn-danger' : 'btn-primary')}
            onClick={async () => {
              if (confirm) await resetData(confirm);
              setConfirm(null);
            }}
          >
            {confirm === 'sample' ? 'Reset portfolio' : 'Clear data'}
          </button>
        </div>
      </Modal>
    </>
  );
}
