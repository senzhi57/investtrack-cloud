import { Banknote, Briefcase, Plus, Sparkles, TrendingUp, Wallet } from 'lucide-react';
import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import AllocationChart from '../components/AllocationChart';
import { useOverlays } from '../components/Overlays';
import PerformanceChart from '../components/PerformanceChart';
import { Change, DemoBadge, EmptyState, PageHeader, Panel, PanelHeader, Sparkline, StatCard } from '../components/ui';
import { INDICES } from '../data/stocks';
import { formatNumber, formatPct, toneClass } from '../lib/format';
import { indexSeries } from '../lib/history';
import { useApp } from '../store/AppContext';

export default function Dashboard() {
  const { summary, data, user, money, resetData } = useApp();
  const { openTrade, openDetail } = useOverlays();
  const navigate = useNavigate();
  const empty = (data?.transactions.length ?? 0) === 0;
  const firstName = (data?.profile.name || user?.name || '').split(' ')[0];

  const indices = useMemo(
    () =>
      INDICES.map((idx) => {
        const series = indexSeries(idx.key, 30).map((p) => p.price);
        series[series.length - 1] = idx.base;
        const change = idx.base - idx.prevClose;
        return { ...idx, series, change, pct: (change / idx.prevClose) * 100 };
      }),
    [],
  );

  return (
    <>
      <PageHeader
        title={`Welcome back, ${firstName}`}
        description="Your virtual portfolio at a glance. Every figure below uses sample DEMO prices."
        actions={
          <button className="btn-primary" onClick={() => openTrade()}>
            <Plus size={16} aria-hidden="true" /> New virtual trade
          </button>
        }
      />

      {empty ? (
        <Panel>
          <EmptyState
            icon={<Briefcase size={22} />}
            title="Your portfolio is empty"
            description="Record your first virtual purchase, or load the sample portfolio to see every chart and metric in action."
            action={
              <>
                <button className="btn-primary" onClick={() => openTrade()}>
                  <Plus size={16} /> Record a purchase
                </button>
                <button className="btn-ghost" onClick={() => resetData('sample')}>
                  <Sparkles size={16} /> Load sample portfolio
                </button>
              </>
            }
          />
        </Panel>
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard label="Total invested" icon={<Banknote size={18} />} value={money(summary.invested)} sub={`${summary.holdings.length} stocks held`} />
            <StatCard
              label="Current portfolio value"
              icon={<Wallet size={18} />}
              value={money(summary.currentValue)}
              sub={<>Plus virtual cash {money(summary.cash)}</>}
              accent
            />
            <StatCard
              label="Total profit / loss"
              icon={<TrendingUp size={18} />}
              tone={summary.totalPnl}
              value={money(summary.totalPnl, { sign: true })}
              sub={
                <>
                  Unrealised {money(summary.unrealizedPnl, { sign: true })} · Realised {money(summary.realizedPnl, { sign: true })}
                </>
              }
            />
            <StatCard
              label="Today's change"
              tone={summary.dayChange}
              value={formatPct(summary.dayChangePct)}
              sub={<span className={toneClass(summary.dayChange)}>{money(summary.dayChange, { sign: true })} vs previous close (demo)</span>}
            />
          </div>

          <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
            <Panel className="xl:col-span-2">
              <PanelHeader title="Portfolio performance" subtitle="Current value of your holdings compared with the amount invested" />
              <PerformanceChart height={380} />
            </Panel>
            <Panel>
              <PanelHeader title="Asset allocation" subtitle="Share of current holdings value" />
              <AllocationChart />
            </Panel>
          </div>

          <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
            <Panel className="xl:col-span-2" pad={false}>
              <div className="p-5 pb-2">
                <PanelHeader
                  title="Top holdings"
                  subtitle="Your five largest positions by current value"
                  action={
                    <button className="btn-ghost !py-1.5 text-xs" onClick={() => navigate('/app/portfolio')}>
                      View all
                    </button>
                  }
                />
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[560px]">
                  <thead>
                    <tr className="border-y border-white/[0.06]">
                      <th className="th">Stock</th>
                      <th className="th text-right">Value</th>
                      <th className="th text-right">Return</th>
                      <th className="th w-40">Weight</th>
                    </tr>
                  </thead>
                  <tbody>
                    {summary.holdings.slice(0, 5).map((h) => (
                      <tr key={h.symbol} onClick={() => openDetail(h.symbol)} className="cursor-pointer border-b border-white/[0.04] transition last:border-0 hover:bg-white/[0.03]">
                        <td className="td">
                          <div className="font-semibold text-white">{h.symbol}</div>
                          <div className="text-xs text-slate-500">{h.name}</div>
                        </td>
                        <td className="td num text-right font-medium text-white">{money(h.currentValue)}</td>
                        <td className="td num text-right">
                          <Change value={h.pnlPct} />
                        </td>
                        <td className="td">
                          <div className="flex items-center gap-2">
                            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
                              <div className="h-full rounded-full bg-emerald-400" style={{ width: `${Math.min(100, h.weight)}%` }} />
                            </div>
                            <span className="num w-11 text-right text-xs text-slate-300">{formatNumber(h.weight, 1)}%</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Panel>

            <Panel>
              <PanelHeader title="Market overview" subtitle={<span className="inline-flex items-center gap-2">Index levels <DemoBadge /></span>} />
              <div className="space-y-3">
                {indices.map((idx) => (
                  <div key={idx.key} className="flex items-center justify-between gap-3 rounded-xl border border-white/[0.06] bg-charcoal-800/60 p-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white">{idx.name}</span>
                        <span className="rounded border border-white/10 px-1.5 text-[10px] text-slate-400">{idx.exchange}</span>
                      </div>
                      <div className="num mt-1.5 font-display text-xl font-semibold text-white">{formatNumber(idx.base)}</div>
                      <div className={`num mt-0.5 text-xs font-semibold ${toneClass(idx.change)}`}>
                        {idx.change >= 0 ? '+' : ''}
                        {formatNumber(idx.change)} ({formatPct(idx.pct)})
                      </div>
                    </div>
                    <Sparkline values={idx.series} positive={idx.change >= 0} />
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[11px] leading-relaxed text-slate-500">Sample index levels for demonstration. They are not live NSE or BSE values.</p>
            </Panel>
          </div>
        </div>
      )}
    </>
  );
}
