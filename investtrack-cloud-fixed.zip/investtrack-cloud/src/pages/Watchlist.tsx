import { Eye, Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { useOverlays } from '../components/Overlays';
import { Change, DemoBadge, EmptyState, PageHeader, Panel } from '../components/ui';
import { SECTOR_COLORS, STOCKS, STOCK_MAP } from '../data/stocks';
import { formatINR, formatMarketCap, formatNumber } from '../lib/format';
import { useApp } from '../store/AppContext';

export default function Watchlist() {
  const { data, quotes, addWatch, removeWatch } = useApp();
  const { openDetail, openTrade } = useOverlays();
  const [pick, setPick] = useState('');
  const [error, setError] = useState('');

  const list = data?.watchlist ?? [];
  const available = STOCKS.filter((s) => !list.includes(s.symbol));

  const add = async () => {
    if (!pick) {
      setError('Choose a stock to add.');
      return;
    }
    setError('');
    await addWatch(pick);
    setPick('');
  };

  return (
    <>
      <PageHeader title="Watchlist" description="Keep an eye on stocks you are interested in without recording a trade." actions={<DemoBadge className="!px-2.5 !py-1 !text-xs" />} />

      <Panel className="mb-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start">
          <div className="flex-1">
            <label htmlFor="w-pick" className="sr-only">
              Stock to add
            </label>
            <select
              id="w-pick"
              className={`input ${error ? 'input-error' : ''}`}
              value={pick}
              disabled={available.length === 0}
              onChange={(e) => {
                setPick(e.target.value);
                setError('');
              }}
            >
              <option value="">{available.length === 0 ? 'Every stock is already on your watchlist' : 'Select a stock to watch'}</option>
              {available.map((s) => (
                <option key={s.symbol} value={s.symbol}>
                  {s.symbol} · {s.name}
                </option>
              ))}
            </select>
            {error && (
              <p role="alert" className="mt-1.5 text-xs text-loss-400">
                {error}
              </p>
            )}
          </div>
          <button className="btn-primary" onClick={add} disabled={available.length === 0}>
            <Plus size={16} aria-hidden="true" /> Add to watchlist
          </button>
        </div>
      </Panel>

      {list.length === 0 ? (
        <Panel>
          <EmptyState
            icon={<Eye size={22} />}
            title="Your watchlist is empty"
            description="Pick a stock above, or use the eye icon in Stock Explorer, to start tracking it here."
          />
        </Panel>
      ) : (
        <Panel pad={false}>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px]">
              <thead>
                <tr className="border-b border-white/[0.06]">
                  <th className="th">Stock</th>
                  <th className="th">Sector</th>
                  <th className="th text-right">Sample price</th>
                  <th className="th text-right">Today</th>
                  <th className="th text-right">Market cap</th>
                  <th className="th text-right">P/E</th>
                  <th className="th text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {list.map((sym) => {
                  const s = STOCK_MAP[sym];
                  const q = quotes[sym];
                  if (!s || !q) return null;
                  const pct = ((q.price - q.prevClose) / q.prevClose) * 100;
                  return (
                    <tr key={sym} className="border-b border-white/[0.04] transition last:border-0 hover:bg-white/[0.03]">
                      <td className="td">
                        <button onClick={() => openDetail(sym)} className="text-left">
                          <div className="font-semibold text-white hover:text-emerald-300">{s.symbol}</div>
                          <div className="text-xs text-slate-500">{s.name}</div>
                        </button>
                      </td>
                      <td className="td">
                        <span className="inline-flex items-center gap-2 text-slate-300">
                          <span className="h-2 w-2 rounded-full" style={{ background: SECTOR_COLORS[s.sector] }} />
                          {s.sector}
                        </span>
                      </td>
                      <td className="td num text-right font-medium text-white">{formatINR(q.price)}</td>
                      <td className="td text-right">
                        <Change value={pct} />
                      </td>
                      <td className="td num text-right text-slate-300">{formatMarketCap(s.marketCapCr)}</td>
                      <td className="td num text-right text-slate-300">{formatNumber(s.pe, 1)}</td>
                      <td className="td">
                        <div className="flex justify-end gap-2">
                          <button className="btn-ghost !px-3 !py-1.5 text-xs" onClick={() => openTrade(sym, 'BUY')}>
                            Buy
                          </button>
                          <button className="btn-danger !px-3 !py-1.5 text-xs" onClick={() => removeWatch(sym)} aria-label={`Remove ${sym} from watchlist`}>
                            <Trash2 size={14} aria-hidden="true" /> Remove
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Panel>
      )}
    </>
  );
}
