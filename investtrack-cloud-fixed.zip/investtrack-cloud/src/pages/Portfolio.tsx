import { Briefcase, Plus, Sparkles } from 'lucide-react';
import { useOverlays } from '../components/Overlays';
import { Change, EmptyState, PageHeader, Panel, StatCard } from '../components/ui';
import { formatInt, formatNumber, formatINR, toneClass } from '../lib/format';
import { useApp } from '../store/AppContext';

export default function Portfolio() {
  const { summary, data, money, resetData } = useApp();
  const { openTrade, openDetail } = useOverlays();
  const empty = (data?.transactions.length ?? 0) === 0;

  return (
    <>
      <PageHeader
        title="My Portfolio"
        description="Record hypothetical purchases and sales. Average price, current value and profit or loss update instantly."
        actions={
          <>
            <button className="btn-danger" onClick={() => openTrade(undefined, 'SELL')} disabled={summary.holdings.length === 0}>
              Record sale
            </button>
            <button className="btn-primary" onClick={() => openTrade(undefined, 'BUY')}>
              <Plus size={16} aria-hidden="true" /> Record purchase
            </button>
          </>
        }
      />

      <div className="mb-6 grid grid-cols-2 gap-4 xl:grid-cols-4">
        <StatCard label="Invested (cost basis)" value={money(summary.invested)} />
        <StatCard label="Current value" value={money(summary.currentValue)} accent />
        <StatCard label="Unrealised P/L" tone={summary.unrealizedPnl} value={money(summary.unrealizedPnl, { sign: true })} sub={<Change value={summary.unrealizedPnlPct} />} />
        <StatCard label="Realised P/L" tone={summary.realizedPnl} value={money(summary.realizedPnl, { sign: true })} sub="From completed sales" />
      </div>

      {empty ? (
        <Panel>
          <EmptyState
            icon={<Briefcase size={22} />}
            title="No holdings yet"
            description="Record a virtual purchase with a quantity and price. Your average price and profit or loss appear here automatically."
            action={
              <>
                <button className="btn-primary" onClick={() => openTrade(undefined, 'BUY')}>
                  <Plus size={16} /> Record a purchase
                </button>
                <button className="btn-ghost" onClick={() => resetData('sample')}>
                  <Sparkles size={16} /> Load sample portfolio
                </button>
              </>
            }
          />
        </Panel>
      ) : summary.holdings.length === 0 ? (
        <Panel>
          <EmptyState
            icon={<Briefcase size={22} />}
            title="You have sold every position"
            description="Your realised profit or loss is shown above. Record a new purchase to start another position."
            action={
              <button className="btn-primary" onClick={() => openTrade(undefined, 'BUY')}>
                <Plus size={16} /> Record a purchase
              </button>
            }
          />
        </Panel>
      ) : (
        <Panel pad={false}>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px]">
              <thead>
                <tr className="border-b border-white/[0.06]">
                  <th className="th">Stock</th>
                  <th className="th text-right">Qty</th>
                  <th className="th text-right">Avg. price</th>
                  <th className="th text-right">Sample price</th>
                  <th className="th text-right">Invested</th>
                  <th className="th text-right">Current value</th>
                  <th className="th text-right">Profit / loss</th>
                  <th className="th text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {summary.holdings.map((h) => (
                  <tr key={h.symbol} className="border-b border-white/[0.04] transition hover:bg-white/[0.03]">
                    <td className="td">
                      <button onClick={() => openDetail(h.symbol)} className="text-left">
                        <div className="font-semibold text-white hover:text-emerald-300">{h.symbol}</div>
                        <div className="text-xs text-slate-500">{h.name}</div>
                      </button>
                    </td>
                    <td className="td num text-right text-white">{formatInt(h.quantity)}</td>
                    <td className="td num text-right text-slate-200">{formatINR(h.avgPrice)}</td>
                    <td className="td num text-right text-slate-200">{formatINR(h.currentPrice)}</td>
                    <td className="td num text-right text-slate-200">{money(h.invested)}</td>
                    <td className="td num text-right font-medium text-white">{money(h.currentValue)}</td>
                    <td className="td num text-right">
                      <div className={`font-semibold ${toneClass(h.pnl)}`}>{money(h.pnl, { sign: true })}</div>
                      <Change value={h.pnlPct} className="text-xs" showIcon={false} />
                    </td>
                    <td className="td">
                      <div className="flex justify-end gap-2">
                        <button className="btn-ghost !px-3 !py-1.5 text-xs" onClick={() => openTrade(h.symbol, 'BUY')}>
                          Buy more
                        </button>
                        <button className="btn-danger !px-3 !py-1.5 text-xs" onClick={() => openTrade(h.symbol, 'SELL')}>
                          Sell
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-white/[0.02]">
                  <td className="td font-semibold text-white" colSpan={4}>
                    Total
                  </td>
                  <td className="td num text-right font-semibold text-white">{money(summary.invested)}</td>
                  <td className="td num text-right font-semibold text-white">{money(summary.currentValue)}</td>
                  <td className={`td num text-right font-semibold ${toneClass(summary.unrealizedPnl)}`}>{money(summary.unrealizedPnl, { sign: true })}</td>
                  <td />
                </tr>
              </tfoot>
            </table>
          </div>
          <div className="border-t border-white/[0.06] px-5 py-3 text-xs text-slate-500">
            Average price uses the weighted-average cost method. Virtual cash left: <span className="num text-slate-300">{formatNumber(summary.cash)}</span> ₹. Sample prices are DEMO DATA.
          </div>
        </Panel>
      )}
    </>
  );
}
