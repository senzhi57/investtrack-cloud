import { Eye, EyeOff, Search, SearchX } from 'lucide-react';
import { useMemo, useState } from 'react';
import { useOverlays } from '../components/Overlays';
import { Change, cx, DemoBadge, EmptyState, PageHeader } from '../components/ui';
import { SECTORS, SECTOR_COLORS, STOCKS } from '../data/stocks';
import { formatINR, formatMarketCap } from '../lib/format';
import { useApp } from '../store/AppContext';
import type { Sector } from '../types';

type SortKey = 'name' | 'price' | 'change';

export default function Explorer() {
  const { quotes, data, toggleWatch } = useApp();
  const { openDetail, openTrade } = useOverlays();
  const [query, setQuery] = useState('');
  const [sector, setSector] = useState<Sector | 'All'>('All');
  const [sort, setSort] = useState<SortKey>('name');

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return STOCKS.map((s) => {
      const quote = quotes[s.symbol];
      const price = quote?.price ?? s.basePrice;
      const prev = quote?.prevClose ?? s.basePrevClose;
      return { stock: s, price, pct: ((price - prev) / prev) * 100 };
    })
      .filter(({ stock }) => (sector === 'All' || stock.sector === sector) && (!q || stock.name.toLowerCase().includes(q) || stock.symbol.toLowerCase().includes(q) || stock.bseCode.includes(q)))
      .sort((a, b) => {
        if (sort === 'price') return b.price - a.price;
        if (sort === 'change') return b.pct - a.pct;
        return a.stock.name.localeCompare(b.stock.name);
      });
  }, [quotes, query, sector, sort]);

  return (
    <>
      <PageHeader
        title="Stock Explorer"
        description="Browse sample Indian companies listed on NSE and BSE. Select one to see its detail and place a virtual trade."
        actions={<DemoBadge className="!px-2.5 !py-1 !text-xs" />}
      />

      <div className="mb-5 flex flex-col gap-3 lg:flex-row lg:items-center">
        <div className="relative flex-1">
          <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" aria-hidden="true" />
          <input
            className="input !pl-10"
            placeholder="Search by company, NSE symbol or BSE code"
            aria-label="Search stocks"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <select className="input lg:!w-48" aria-label="Sort stocks" value={sort} onChange={(e) => setSort(e.target.value as SortKey)}>
          <option value="name">Sort: Company name</option>
          <option value="price">Sort: Highest price</option>
          <option value="change">Sort: Biggest gain</option>
        </select>
      </div>

      <div className="mb-6 flex flex-wrap gap-2" role="group" aria-label="Filter by sector">
        {(['All', ...SECTORS] as const).map((s) => (
          <button
            key={s}
            onClick={() => setSector(s)}
            aria-pressed={sector === s}
            className={cx(
              'flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-xs font-semibold transition',
              sector === s ? 'border-emerald-500/60 bg-emerald-500/15 text-emerald-300' : 'border-white/10 text-slate-400 hover:border-white/25 hover:text-white',
            )}
          >
            {s !== 'All' && <span className="h-2 w-2 rounded-full" style={{ background: SECTOR_COLORS[s] }} />}
            {s}
          </button>
        ))}
      </div>

      {rows.length === 0 ? (
        <EmptyState
          icon={<SearchX size={22} />}
          title="No stocks match your search"
          description="Check the spelling or clear the sector filter to see all companies."
          action={
            <button
              className="btn-ghost"
              onClick={() => {
                setQuery('');
                setSector('All');
              }}
            >
              Clear filters
            </button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {rows.map(({ stock, price, pct }) => {
            const watched = data?.watchlist.includes(stock.symbol);
            return (
              <article
                key={stock.symbol}
                className="panel group flex cursor-pointer flex-col p-5 transition hover:-translate-y-0.5 hover:border-emerald-500/30"
                onClick={() => openDetail(stock.symbol)}
                tabIndex={0}
                onKeyDown={(e) => e.key === 'Enter' && openDetail(stock.symbol)}
                aria-label={`${stock.name} details`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="rounded-md bg-white/10 px-2 py-0.5 text-xs font-bold text-white">{stock.symbol}</span>
                      <span className="rounded border border-white/10 px-1.5 py-0.5 text-[10px] text-slate-400">NSE</span>
                      <span className="rounded border border-white/10 px-1.5 py-0.5 text-[10px] text-slate-400">BSE</span>
                    </div>
                    <h3 className="mt-2.5 truncate font-display text-[15px] font-semibold text-white">{stock.name}</h3>
                    <p className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-400">
                      <span className="h-2 w-2 rounded-full" style={{ background: SECTOR_COLORS[stock.sector] }} />
                      {stock.sector} · {formatMarketCap(stock.marketCapCr)}
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleWatch(stock.symbol);
                    }}
                    aria-label={watched ? `Remove ${stock.symbol} from watchlist` : `Add ${stock.symbol} to watchlist`}
                    title={watched ? 'Remove from watchlist' : 'Add to watchlist'}
                    className={cx('rounded-lg p-2 transition', watched ? 'bg-emerald-500/15 text-emerald-300' : 'text-slate-500 hover:bg-white/10 hover:text-white')}
                  >
                    {watched ? <Eye size={16} /> : <EyeOff size={16} />}
                  </button>
                </div>

                <div className="mt-5 flex items-end justify-between">
                  <div>
                    <div className="num font-display text-2xl font-semibold text-white">{formatINR(price)}</div>
                    <div className="mt-1 flex items-center gap-1.5">
                      <DemoBadge />
                    </div>
                  </div>
                  <Change value={pct} className="text-sm" />
                </div>

                <button
                  className="btn-ghost mt-4 !py-2 text-xs opacity-100 transition sm:opacity-0 sm:group-hover:opacity-100 sm:focus:opacity-100"
                  onClick={(e) => {
                    e.stopPropagation();
                    openTrade(stock.symbol, 'BUY');
                  }}
                >
                  Buy virtually
                </button>
              </article>
            );
          })}
        </div>
      )}
    </>
  );
}
