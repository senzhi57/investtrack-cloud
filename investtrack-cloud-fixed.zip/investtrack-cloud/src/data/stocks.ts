import type { Sector, Stock } from '../types';

/**
 * ---------------------------------------------------------------
 *  DEMO DATA ONLY
 *  Every price, ratio and market-cap value below is a made-up
 *  sample for classroom demonstration. These are NOT live or
 *  historical NSE / BSE quotes and must never be presented as such.
 * ---------------------------------------------------------------
 */
export const STOCKS: Stock[] = [
  {
    symbol: 'TCS',
    bseCode: '532540',
    name: 'Tata Consultancy Services',
    sector: 'IT',
    basePrice: 3980.4,
    basePrevClose: 3951.1,
    marketCapCr: 1440000,
    pe: 29.4,
    dividendYield: 1.4,
    about: 'Global IT services, consulting and business solutions company with a large Indian delivery footprint.',
    seed: 11,
    drift: 0.12,
  },
  {
    symbol: 'INFY',
    bseCode: '500209',
    name: 'Infosys',
    sector: 'IT',
    basePrice: 1845.7,
    basePrevClose: 1862.3,
    marketCapCr: 765000,
    pe: 25.1,
    dividendYield: 2.3,
    about: 'Digital services and consulting company providing software, cloud and AI-led transformation work.',
    seed: 23,
    drift: 0.08,
  },
  {
    symbol: 'RELIANCE',
    bseCode: '500325',
    name: 'Reliance Industries',
    sector: 'Energy',
    basePrice: 2960.25,
    basePrevClose: 2934.8,
    marketCapCr: 2000000,
    pe: 27.8,
    dividendYield: 0.4,
    about: 'Diversified conglomerate spanning energy, petrochemicals, retail and digital services.',
    seed: 37,
    drift: 0.14,
  },
  {
    symbol: 'HDFCBANK',
    bseCode: '500180',
    name: 'HDFC Bank',
    sector: 'Banking',
    basePrice: 1720.9,
    basePrevClose: 1708.55,
    marketCapCr: 1310000,
    pe: 19.6,
    dividendYield: 1.1,
    about: 'Large private sector bank offering retail, wholesale and digital banking services.',
    seed: 41,
    drift: 0.1,
  },
  {
    symbol: 'ICICIBANK',
    bseCode: '532174',
    name: 'ICICI Bank',
    sector: 'Banking',
    basePrice: 1285.35,
    basePrevClose: 1271.9,
    marketCapCr: 905000,
    pe: 18.2,
    dividendYield: 0.9,
    about: 'Private sector bank with a broad retail franchise and strong digital banking presence.',
    seed: 53,
    drift: 0.16,
  },
  {
    symbol: 'WIPRO',
    bseCode: '507685',
    name: 'Wipro',
    sector: 'IT',
    basePrice: 545.6,
    basePrevClose: 551.2,
    marketCapCr: 285000,
    pe: 22.7,
    dividendYield: 1.8,
    about: 'IT services and consulting company with operations across cloud, engineering and digital operations.',
    seed: 67,
    drift: 0.02,
  },
  {
    symbol: 'ITC',
    bseCode: '500875',
    name: 'ITC Limited',
    sector: 'FMCG',
    basePrice: 468.15,
    basePrevClose: 465.4,
    marketCapCr: 585000,
    pe: 26.3,
    dividendYield: 3.1,
    about: 'Diversified group with FMCG, hotels, paperboards and agri-business verticals.',
    seed: 71,
    drift: 0.05,
  },
  {
    symbol: 'TATAMOTORS',
    bseCode: '500570',
    name: 'Tata Motors',
    sector: 'Automobile',
    basePrice: 985.5,
    basePrevClose: 1002.1,
    marketCapCr: 365000,
    pe: 11.9,
    dividendYield: 0.3,
    about: 'Automotive manufacturer of passenger, commercial and electric vehicles including global luxury brands.',
    seed: 83,
    drift: 0.09,
  },
  {
    symbol: 'NATIONALUM',
    bseCode: '532234',
    name: 'NALCO (National Aluminium Co.)',
    sector: 'Metals',
    basePrice: 192.4,
    basePrevClose: 188.95,
    marketCapCr: 35400,
    pe: 10.6,
    dividendYield: 2.6,
    about: 'Public sector integrated aluminium producer covering bauxite mining, alumina refining and smelting.',
    seed: 97,
    drift: 0.18,
  },
  {
    symbol: 'SBIN',
    bseCode: '500112',
    name: 'State Bank of India',
    sector: 'Banking',
    basePrice: 842.3,
    basePrevClose: 836.7,
    marketCapCr: 752000,
    pe: 10.2,
    dividendYield: 1.7,
    about: 'India\'s largest public sector bank with a nationwide branch network.',
    seed: 109,
    drift: 0.13,
  },
];

export const STOCK_MAP: Record<string, Stock> = Object.fromEntries(STOCKS.map((s) => [s.symbol, s]));

export const SECTORS: Sector[] = ['IT', 'Banking', 'Energy', 'FMCG', 'Automobile', 'Metals'];

/** DEMO index levels. Not live NSE/BSE index values. */
export interface IndexInfo {
  key: 'NIFTY50' | 'SENSEX';
  name: string;
  exchange: 'NSE' | 'BSE';
  base: number;
  prevClose: number;
  seed: number;
  drift: number;
}

export const INDICES: IndexInfo[] = [
  { key: 'NIFTY50', name: 'NIFTY 50', exchange: 'NSE', base: 24385.6, prevClose: 24302.15, seed: 201, drift: 0.1 },
  { key: 'SENSEX', name: 'SENSEX', exchange: 'BSE', base: 80214.8, prevClose: 79948.4, seed: 307, drift: 0.09 },
];

export const DEMO_LABEL = 'DEMO DATA';
export const DEMO_NOTICE =
  'All prices on this platform are sample DEMO DATA. They are not live NSE/BSE quotes and no real trades are placed.';

/** Stable colors per sector (checked against the dark surface). */
export const SECTOR_COLORS: Record<Sector, string> = {
  IT: '#3987e5',
  Banking: '#199e70',
  Energy: '#d95926',
  FMCG: '#c98500',
  Automobile: '#9085e9',
  Metals: '#d55181',
};

/** Ordered, CVD-validated categorical palette for dark surfaces. */
export const CATEGORICAL = ['#3987e5', '#d95926', '#199e70', '#c98500', '#d55181', '#008300', '#9085e9', '#e66767'];
export const OTHER_COLOR = '#7d8bab';
