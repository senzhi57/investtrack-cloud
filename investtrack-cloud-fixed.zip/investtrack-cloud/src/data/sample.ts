import type { Preferences, SessionUser, Transaction, UserData, UserProfile } from '../types';
import { addDays, roundTo, todayISO } from '../lib/format';
import { stockPriceOn } from '../lib/history';

export const DEFAULT_PREFERENCES: Preferences = {
  numberFormat: 'full',
  defaultExchange: 'NSE',
  defaultRange: '6M',
  showDemoBanner: true,
  startingCapital: 1_000_000,
};

export function defaultProfile(user: SessionUser): UserProfile {
  return {
    name: user.name,
    email: user.email,
    institution: user.isDemo ? 'B.Tech Cloud Computing Mini Project' : '',
    investorType: 'Beginner',
  };
}

interface Seed {
  daysAgo: number;
  symbol: string;
  side: 'BUY' | 'SELL';
  qty: number;
  exchange?: 'NSE' | 'BSE';
}

const SEEDS: Seed[] = [
  { daysAgo: 170, symbol: 'TCS', side: 'BUY', qty: 15 },
  { daysAgo: 150, symbol: 'RELIANCE', side: 'BUY', qty: 20 },
  { daysAgo: 140, symbol: 'HDFCBANK', side: 'BUY', qty: 40 },
  { daysAgo: 120, symbol: 'INFY', side: 'BUY', qty: 30 },
  { daysAgo: 100, symbol: 'ITC', side: 'BUY', qty: 150, exchange: 'BSE' },
  { daysAgo: 85, symbol: 'SBIN', side: 'BUY', qty: 50 },
  { daysAgo: 70, symbol: 'TATAMOTORS', side: 'BUY', qty: 40 },
  { daysAgo: 55, symbol: 'NATIONALUM', side: 'BUY', qty: 200 },
  { daysAgo: 45, symbol: 'ICICIBANK', side: 'BUY', qty: 40 },
  { daysAgo: 35, symbol: 'ITC', side: 'SELL', qty: 50 },
  { daysAgo: 12, symbol: 'INFY', side: 'SELL', qty: 10 },
  { daysAgo: 6, symbol: 'TCS', side: 'BUY', qty: 5 },
];

/** Builds the first-time demonstration portfolio. Prices come from the DEMO history generator. */
export function buildSampleTransactions(userId: string): Transaction[] {
  const today = todayISO();
  return SEEDS.map((s, i) => {
    const date = addDays(today, -s.daysAgo);
    return {
      id: `seed_${i + 1}`,
      userId,
      symbol: s.symbol,
      side: s.side,
      exchange: s.exchange ?? 'NSE',
      quantity: s.qty,
      price: roundTo(stockPriceOn(s.symbol, date)),
      date,
      createdAt: `${date}T10:15:00.000Z`,
    };
  });
}

export function buildSampleData(user: SessionUser, startingCapital = DEFAULT_PREFERENCES.startingCapital): UserData {
  return {
    transactions: buildSampleTransactions(user.id),
    watchlist: ['WIPRO', 'ICICIBANK', 'RELIANCE'],
    profile: defaultProfile(user),
    preferences: { ...DEFAULT_PREFERENCES, startingCapital },
  };
}

export function buildEmptyData(user: SessionUser, startingCapital = DEFAULT_PREFERENCES.startingCapital): UserData {
  return {
    transactions: [],
    watchlist: [],
    profile: defaultProfile(user),
    preferences: { ...DEFAULT_PREFERENCES, startingCapital },
  };
}
