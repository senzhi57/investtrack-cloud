export type Exchange = 'NSE' | 'BSE';
export type Side = 'BUY' | 'SELL';

export type Sector = 'IT' | 'Banking' | 'Energy' | 'FMCG' | 'Automobile' | 'Metals';

export interface Stock {
  symbol: string; // NSE trading symbol
  bseCode: string;
  name: string;
  sector: Sector;
  /** DEMO base price in INR. Never a live NSE/BSE quote. */
  basePrice: number;
  /** DEMO previous close used to compute demo daily movement. */
  basePrevClose: number;
  marketCapCr: number; // demo, in crore
  pe: number; // demo
  dividendYield: number; // demo, %
  about: string;
  seed: number; // seeds the deterministic demo price history
  drift: number; // yearly drift used by the demo history generator
}

/** A demo quote. `isDemo` is always true in this build. */
export interface Quote {
  symbol: string;
  price: number;
  prevClose: number;
  isDemo: true;
}

export type QuoteMap = Record<string, Quote>;

export interface Transaction {
  id: string;
  userId: string;
  symbol: string;
  side: Side;
  exchange: Exchange;
  quantity: number;
  price: number;
  /** ISO date (yyyy-mm-dd) the user says the virtual trade happened */
  date: string;
  /** ISO timestamp the record was created */
  createdAt: string;
}

export interface OrderInput {
  symbol: string;
  side: Side;
  exchange: Exchange;
  quantity: number;
  price: number;
  date: string;
}

export interface Holding {
  symbol: string;
  name: string;
  sector: Sector;
  quantity: number;
  avgPrice: number;
  invested: number;
  currentPrice: number;
  currentValue: number;
  pnl: number;
  pnlPct: number;
  dayChange: number;
  dayChangePct: number;
  weight: number; // % of current holdings value
}

export interface PortfolioSummary {
  holdings: Holding[];
  invested: number;
  currentValue: number;
  unrealizedPnl: number;
  unrealizedPnlPct: number;
  realizedPnl: number;
  totalPnl: number;
  totalPnlPct: number;
  dayChange: number;
  dayChangePct: number;
  cash: number;
  netWorth: number; // cash + current value
}

export interface UserProfile {
  name: string;
  email: string;
  institution: string;
  investorType: 'Beginner' | 'Intermediate' | 'Advanced';
}

export interface Preferences {
  numberFormat: 'full' | 'compact';
  defaultExchange: Exchange;
  defaultRange: '1M' | '3M' | '6M';
  showDemoBanner: boolean;
  startingCapital: number;
}

export interface UserData {
  transactions: Transaction[];
  watchlist: string[];
  profile: UserProfile;
  preferences: Preferences;
}

export interface SessionUser {
  id: string;
  name: string;
  email: string;
  isDemo: boolean;
}

export interface ValidationResult {
  ok: boolean;
  errors: Partial<Record<'symbol' | 'quantity' | 'price' | 'date' | 'form', string>>;
}
