import { HashRouter, Navigate, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import { Logo } from './components/ui';
import Analytics from './pages/Analytics';
import Dashboard from './pages/Dashboard';
import Explorer from './pages/Explorer';
import Landing from './pages/Landing';
import Portfolio from './pages/Portfolio';
import Settings from './pages/Settings';
import Transactions from './pages/Transactions';
import Watchlist from './pages/Watchlist';
import { AppProvider, useApp } from './store/AppContext';

function Protected() {
  const { booting, user, data } = useApp();
  if (booting || (user && !data)) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="flex animate-pop flex-col items-center gap-4">
          <Logo />
          <span className="text-sm text-slate-400">Loading your portfolio…</span>
        </div>
      </div>
    );
  }
  if (!user) return <Navigate to="/" replace />;
  return <Layout />;
}

export default function App() {
  return (
    <AppProvider>
      {/* HashRouter keeps routing working on static hosts such as S3 without rewrite rules. */}
      <HashRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/app" element={<Protected />}>
            <Route index element={<Dashboard />} />
            <Route path="explorer" element={<Explorer />} />
            <Route path="portfolio" element={<Portfolio />} />
            <Route path="watchlist" element={<Watchlist />} />
            <Route path="transactions" element={<Transactions />} />
            <Route path="analytics" element={<Analytics />} />
            <Route path="settings" element={<Settings />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </HashRouter>
    </AppProvider>
  );
}
