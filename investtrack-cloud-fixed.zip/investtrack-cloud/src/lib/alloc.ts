import { CATEGORICAL, OTHER_COLOR, SECTORS, SECTOR_COLORS } from '../data/stocks';
import type { Holding } from '../types';

export interface Slice {
  name: string;
  value: number;
  pct: number;
  color: string;
}

/** Top 7 holdings get fixed categorical slots in order; the rest fold into "Other". */
export function allocationByStock(holdings: Holding[]): Slice[] {
  const total = holdings.reduce((s, h) => s + h.currentValue, 0);
  if (total <= 0) return [];
  const sorted = [...holdings].sort((a, b) => b.currentValue - a.currentValue);
  const top = sorted.slice(0, 7);
  const rest = sorted.slice(7);
  const slices: Slice[] = top.map((h, i) => ({
    name: h.symbol,
    value: h.currentValue,
    pct: (h.currentValue / total) * 100,
    color: CATEGORICAL[i],
  }));
  if (rest.length) {
    const v = rest.reduce((s, h) => s + h.currentValue, 0);
    slices.push({ name: 'Other', value: v, pct: (v / total) * 100, color: OTHER_COLOR });
  }
  return slices;
}

export function allocationBySector(holdings: Holding[]): Slice[] {
  const total = holdings.reduce((s, h) => s + h.currentValue, 0);
  if (total <= 0) return [];
  return SECTORS.map((sec) => {
    const v = holdings.filter((h) => h.sector === sec).reduce((s, h) => s + h.currentValue, 0);
    return { name: sec, value: v, pct: (v / total) * 100, color: SECTOR_COLORS[sec] };
  })
    .filter((s) => s.value > 0)
    .sort((a, b) => b.value - a.value);
}
