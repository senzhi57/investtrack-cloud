import { STOCK_MAP } from '../data/stocks';
import type { Holding, OrderInput, PortfolioSummary, QuoteMap, Transaction, ValidationResult } from '../types';
import { addDays, dayIndex, roundTo, todayISO } from './format';
import { stockPriceOn } from './history';

/**
 * Sort chronologically. Trades on the same day replay in the order they were entered
 * (createdAt), because a sale must be costed against the holding as it stood at that
 * moment, not against shares bought later that day. Only when the entry time is
 * identical do BUYs come first. (Array.sort is stable, so equal keys keep input order.)
 */
export function sortTransactions(txns: Transaction[]): Transaction[] {
  return [...txns].sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? -1 : 1;
    if (a.createdAt !== b.createdAt) return a.createdAt < b.createdAt ? -1 : 1;
    if (a.side !== b.side) return a.side === 'BUY' ? -1 : 1;
    return 0;
  });
}

interface Position {
  quantity: number;
  avgPrice: number;
}

interface ReplayResult {
  positions: Record<string, Position>;
  realizedPnl: number;
  /** Cost basis (at weighted-average cost) of every share sold so far. */
  soldCost: number;
  cash: number;
  minCash: number;
  negativeSymbol: string | null;
}

/** Replays transactions with the weighted-average-cost method. */
export function replay(txns: Transaction[], startingCapital: number): ReplayResult {
  const positions: Record<string, Position> = {};
  let realized = 0;
  let soldCost = 0;
  let cash = startingCapital;
  let minCash = cash;
  let negativeSymbol: string | null = null;

  for (const t of sortTransactions(txns)) {
    const pos = positions[t.symbol] ?? { quantity: 0, avgPrice: 0 };
    const amount = t.quantity * t.price;
    if (t.side === 'BUY') {
      const newQty = pos.quantity + t.quantity;
      pos.avgPrice = newQty === 0 ? 0 : (pos.quantity * pos.avgPrice + amount) / newQty;
      pos.quantity = newQty;
      cash -= amount;
    } else {
      if (t.quantity > pos.quantity + 1e-9) negativeSymbol = negativeSymbol ?? t.symbol;
      const sellQty = Math.min(t.quantity, pos.quantity);
      realized += (t.price - pos.avgPrice) * t.quantity;
      soldCost += pos.avgPrice * sellQty;
      pos.quantity -= t.quantity;
      if (pos.quantity <= 1e-9) {
        pos.quantity = 0;
        pos.avgPrice = 0;
      }
      cash += amount;
    }
    positions[t.symbol] = pos;
    minCash = Math.min(minCash, cash);
  }
  return { positions, realizedPnl: realized, soldCost, cash, minCash, negativeSymbol };
}

export function computeSummary(txns: Transaction[], quotes: QuoteMap, startingCapital: number): PortfolioSummary {
  const r = replay(txns, startingCapital);
  const raw: Omit<Holding, 'weight'>[] = [];

  for (const [symbol, pos] of Object.entries(r.positions)) {
    if (pos.quantity <= 0) continue;
    const stock = STOCK_MAP[symbol];
    const q = quotes[symbol];
    if (!stock || !q) continue;
    const invested = pos.quantity * pos.avgPrice;
    const currentValue = pos.quantity * q.price;
    const pnl = currentValue - invested;
    const dayChange = pos.quantity * (q.price - q.prevClose);
    raw.push({
      symbol,
      name: stock.name,
      sector: stock.sector,
      quantity: pos.quantity,
      avgPrice: pos.avgPrice,
      invested,
      currentPrice: q.price,
      currentValue,
      pnl,
      pnlPct: invested > 0 ? (pnl / invested) * 100 : 0,
      dayChange,
      dayChangePct: q.prevClose > 0 ? ((q.price - q.prevClose) / q.prevClose) * 100 : 0,
    });
  }

  const totalValue = raw.reduce((s, h) => s + h.currentValue, 0);
  const holdings: Holding[] = raw
    .map((h) => ({ ...h, weight: totalValue > 0 ? (h.currentValue / totalValue) * 100 : 0 }))
    .sort((a, b) => b.currentValue - a.currentValue);

  const invested = holdings.reduce((s, h) => s + h.invested, 0);
  const unrealizedPnl = totalValue - invested;
  const dayChange = holdings.reduce((s, h) => s + h.dayChange, 0);
  const prevValue = totalValue - dayChange;
  const totalPnl = unrealizedPnl + r.realizedPnl;

  return {
    holdings,
    invested,
    currentValue: totalValue,
    unrealizedPnl,
    unrealizedPnlPct: invested > 0 ? (unrealizedPnl / invested) * 100 : 0,
    realizedPnl: r.realizedPnl,
    totalPnl,
    // Return on all capital deployed at cost: what is still held plus what has been sold.
    totalPnlPct: invested + r.soldCost > 0 ? (totalPnl / (invested + r.soldCost)) * 100 : 0,
    dayChange,
    dayChangePct: prevValue > 0 ? (dayChange / prevValue) * 100 : 0,
    cash: r.cash,
    netWorth: r.cash + totalValue,
  };
}

export interface HistoryPoint {
  date: string;
  value: number;
  invested: number;
}

/**
 * Historical portfolio value, built by replaying transactions day by day and
 * valuing quantities held on each day with the DEMO price history.
 */
export function portfolioHistory(txns: Transaction[], quotes: QuoteMap, days: number): HistoryPoint[] {
  if (txns.length === 0) return [];
  const sorted = sortTransactions(txns);
  const today = todayISO();
  const first = sorted[0].date;
  const windowStart = addDays(today, -days);
  const start = first > windowStart ? first : windowStart;
  const startIdx = dayIndex(start);
  const endIdx = dayIndex(today);

  const pos: Record<string, Position> = {};
  let ti = 0;
  const out: HistoryPoint[] = [];

  // apply everything before the window
  while (ti < sorted.length && sorted[ti].date < start) {
    applyTxn(pos, sorted[ti]);
    ti++;
  }

  for (let d = startIdx; d <= endIdx; d++) {
    const date = addDays(start, d - startIdx);
    while (ti < sorted.length && sorted[ti].date <= date) {
      applyTxn(pos, sorted[ti]);
      ti++;
    }
    let value = 0;
    let invested = 0;
    for (const [sym, p] of Object.entries(pos)) {
      if (p.quantity <= 0) continue;
      const price = date === today ? quotes[sym]?.price ?? stockPriceOn(sym, date) : stockPriceOn(sym, date);
      value += p.quantity * price;
      invested += p.quantity * p.avgPrice;
    }
    out.push({ date, value: roundTo(value), invested: roundTo(invested) });
  }
  return out;
}

function applyTxn(pos: Record<string, Position>, t: Transaction) {
  const p = pos[t.symbol] ?? { quantity: 0, avgPrice: 0 };
  if (t.side === 'BUY') {
    const q = p.quantity + t.quantity;
    p.avgPrice = q === 0 ? 0 : (p.quantity * p.avgPrice + t.quantity * t.price) / q;
    p.quantity = q;
  } else {
    p.quantity = Math.max(0, p.quantity - t.quantity);
    if (p.quantity === 0) p.avgPrice = 0;
  }
  pos[t.symbol] = p;
}

/**
 * Validates a proposed virtual order against the existing transactions.
 * Replays the whole ledger with the new order inserted so back-dated orders
 * cannot create negative holdings or negative cash at any point in time.
 *
 * NOTE: when a backend exists (Lambda), the same checks MUST run server-side.
 */
export function validateOrder(input: Partial<OrderInput>, existing: Transaction[], startingCapital: number): ValidationResult {
  const errors: ValidationResult['errors'] = {};
  const today = todayISO();

  if (!input.symbol || !STOCK_MAP[input.symbol]) errors.symbol = 'Choose a stock from the list.';

  const qty = Number(input.quantity);
  if (input.quantity === undefined || (input.quantity as unknown) === '' || Number.isNaN(qty)) {
    errors.quantity = 'Enter a quantity.';
  } else if (!Number.isInteger(qty)) {
    errors.quantity = 'Quantity must be a whole number of shares.';
  } else if (qty <= 0) {
    errors.quantity = 'Quantity must be at least 1.';
  } else if (qty > 1_000_000) {
    errors.quantity = 'Quantity cannot exceed 10,00,000 shares.';
  }

  const price = Number(input.price);
  if (input.price === undefined || (input.price as unknown) === '' || Number.isNaN(price)) {
    errors.price = 'Enter a price per share.';
  } else if (price <= 0) {
    errors.price = 'Price must be greater than ₹0.';
  } else if (price > 10_000_000) {
    errors.price = 'Price looks too high. Check the amount.';
  }

  if (!input.date) {
    errors.date = 'Choose a transaction date.';
  } else if (input.date > today) {
    errors.date = 'Transaction date cannot be in the future.';
  } else if (input.date < addDays(today, -730)) {
    errors.date = 'Date cannot be more than 2 years ago.';
  }

  if (Object.keys(errors).length > 0) return { ok: false, errors };

  const candidate: Transaction = {
    id: '__candidate__',
    userId: '',
    symbol: input.symbol!,
    side: input.side ?? 'BUY',
    exchange: input.exchange ?? 'NSE',
    quantity: qty,
    price,
    date: input.date!,
    createdAt: new Date().toISOString(),
  };
  const r = replay([...existing, candidate], startingCapital);

  if (candidate.side === 'SELL' && r.negativeSymbol) {
    const held = replay(existing.filter((t) => t.date <= candidate.date), startingCapital).positions[candidate.symbol]?.quantity ?? 0;
    errors.quantity = `You only held ${held} share${held === 1 ? '' : 's'} of ${candidate.symbol} on that date.`;
  } else if (candidate.side === 'BUY' && r.minCash < -0.005) {
    errors.form = 'Not enough virtual cash for this purchase. Reduce the quantity or add capital in Settings.';
  } else if (r.negativeSymbol) {
    errors.form = `This order would leave ${r.negativeSymbol} with a negative holding on a later sale date.`;
  } else if (r.minCash < -0.005) {
    errors.form = 'This order would make your virtual cash negative on a later date.';
  }

  return { ok: Object.keys(errors).length === 0, errors };
}

export function heldQuantity(txns: Transaction[], symbol: string): number {
  return replay(txns, 0).positions[symbol]?.quantity ?? 0;
}
