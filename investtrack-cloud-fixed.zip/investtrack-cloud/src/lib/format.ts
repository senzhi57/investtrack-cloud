const inr = new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const inrInt = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 });

export function formatINR(value: number, opts: { compact?: boolean; decimals?: boolean; sign?: boolean } = {}): string {
  if (!Number.isFinite(value)) return '₹0.00';
  const { compact = false, decimals = true, sign = false } = opts;
  const abs = Math.abs(value);
  const prefix = value < 0 ? '-' : sign && value > 0 ? '+' : '';
  if (compact) {
    if (abs >= 1e7) return `${prefix}₹${(abs / 1e7).toFixed(2)} Cr`;
    if (abs >= 1e5) return `${prefix}₹${(abs / 1e5).toFixed(2)} L`;
    if (abs >= 1e3) return `${prefix}₹${(abs / 1e3).toFixed(1)}K`;
  }
  return `${prefix}₹${decimals ? inr.format(abs) : inrInt.format(abs)}`;
}

export function formatNumber(value: number, digits = 2): string {
  return new Intl.NumberFormat('en-IN', { minimumFractionDigits: digits, maximumFractionDigits: digits }).format(value);
}

export function formatInt(value: number): string {
  return inrInt.format(value);
}

export function formatPct(value: number, opts: { sign?: boolean; digits?: number } = {}): string {
  const { sign = true, digits = 2 } = opts;
  if (!Number.isFinite(value)) return '0.00%';
  const prefix = value > 0 && sign ? '+' : '';
  return `${prefix}${value.toFixed(digits)}%`;
}

export function formatMarketCap(cr: number): string {
  if (cr >= 100000) return `₹${(cr / 100000).toFixed(2)} L Cr`;
  return `₹${inrInt.format(cr)} Cr`;
}

export function formatDate(iso: string): string {
  const d = new Date(iso + (iso.length === 10 ? 'T00:00:00' : ''));
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function formatShortDate(iso: string): string {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
}

export function todayISO(): string {
  const d = new Date();
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
}

export function addDays(iso: string, days: number): string {
  const d = new Date(iso + 'T00:00:00');
  d.setDate(d.getDate() + days);
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
}

export function dayIndex(iso: string): number {
  return Math.floor(new Date(iso + 'T00:00:00Z').getTime() / 86400000);
}

export function roundTo(n: number, dp = 2): number {
  const f = Math.pow(10, dp);
  return Math.round((n + Number.EPSILON) * f) / f;
}

export function toneClass(value: number): string {
  if (value > 0) return 'text-emerald-400';
  if (value < 0) return 'text-loss-400';
  return 'text-slate-400';
}

export function uid(prefix = 'id'): string {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}
