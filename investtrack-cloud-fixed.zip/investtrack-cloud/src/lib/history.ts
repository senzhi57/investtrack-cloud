import { INDICES, STOCK_MAP } from '../data/stocks';
import { addDays, dayIndex, todayISO } from './format';

/**
 * DEMO price history generator.
 * Produces deterministic, plausible-looking sample series for any date.
 * It is a pure function of (seed, date) so charts are stable across reloads.
 * NOT real market history.
 */
function hash(seed: number, n: number): number {
  let x = (seed * 374761393 + n * 668265263) | 0;
  x = (x ^ (x >>> 13)) * 1274126177;
  x = x ^ (x >>> 16);
  return ((x >>> 0) % 100000) / 100000; // 0..1
}

function factor(seed: number, drift: number, t: number, dayAbs: number): number {
  const p1 = (seed % 17) * 0.37;
  const p2 = (seed % 29) * 0.21;
  const noise = (hash(seed, dayAbs) - 0.5) * 0.016;
  return 1 + (drift * t) / 365 + 0.055 * Math.sin(t / 19 + p1) + 0.035 * Math.sin(t / 61 + p2) + noise;
}

export interface SeriesPoint {
  date: string;
  price: number;
}

/** Price on a given date, anchored so that "today" equals the base price. */
export function demoPriceOn(base: number, seed: number, drift: number, date: string, today = todayISO()): number {
  const tNow = dayIndex(today);
  const d = dayIndex(date);
  const t = d - tNow;
  const f0 = factor(seed, drift, 0, tNow);
  return Math.max(1, (base * factor(seed, drift, t, d)) / f0);
}

export function stockPriceOn(symbol: string, date: string): number {
  const s = STOCK_MAP[symbol];
  if (!s) return 0;
  return demoPriceOn(s.basePrice, s.seed, s.drift, date);
}

export function stockSeries(symbol: string, days: number, currentPrice?: number): SeriesPoint[] {
  const s = STOCK_MAP[symbol];
  if (!s) return [];
  const today = todayISO();
  const out: SeriesPoint[] = [];
  for (let i = days; i >= 0; i--) {
    const date = addDays(today, -i);
    out.push({ date, price: demoPriceOn(s.basePrice, s.seed, s.drift, date, today) });
  }
  if (currentPrice !== undefined) out[out.length - 1].price = currentPrice;
  return out;
}

export function indexSeries(key: 'NIFTY50' | 'SENSEX', days: number): SeriesPoint[] {
  const idx = INDICES.find((i) => i.key === key)!;
  const today = todayISO();
  const out: SeriesPoint[] = [];
  for (let i = days; i >= 0; i--) {
    const date = addDays(today, -i);
    out.push({ date, price: demoPriceOn(idx.base, idx.seed, idx.drift, date, today) });
  }
  return out;
}

export const RANGE_DAYS: Record<'1M' | '3M' | '6M' | '1Y', number> = { '1M': 30, '3M': 90, '6M': 180, '1Y': 365 };
