import { useMemo, useState } from 'react';
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import { allocationBySector, allocationByStock } from '../lib/alloc';
import { formatPct } from '../lib/format';
import { useApp } from '../store/AppContext';
import { ChartTooltip, Segmented } from './ui';

const MODES = ['Stock', 'Sector'] as const;

export default function AllocationChart({ height = 220 }: { height?: number }) {
  const { summary, money } = useApp();
  const [mode, setMode] = useState<(typeof MODES)[number]>('Stock');
  const slices = useMemo(
    () => (mode === 'Stock' ? allocationByStock(summary.holdings) : allocationBySector(summary.holdings)),
    [mode, summary.holdings],
  );

  return (
    <div>
      <div className="mb-3 flex justify-end">
        <Segmented options={MODES} value={mode} onChange={setMode} label="Allocation grouping" />
      </div>
      <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-4">
        <div className="relative w-[220px] shrink-0" style={{ height }}>
          <ResponsiveContainer>
            <PieChart>
              <Pie data={slices} dataKey="value" nameKey="name" innerRadius="62%" outerRadius="94%" paddingAngle={2} stroke="#0f1829" strokeWidth={2} isAnimationActive={false}>
                {slices.map((s) => (
                  <Cell key={s.name} fill={s.color} />
                ))}
              </Pie>
              <Tooltip content={<ChartTooltip format={(v) => money(v)} />} />
            </PieChart>
          </ResponsiveContainer>
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-[11px] text-slate-400">Holdings</span>
            <span className="num font-display text-base font-semibold text-white">{money(summary.currentValue)}</span>
          </div>
        </div>
        <ul className="min-w-[190px] flex-1 space-y-2" aria-label="Allocation breakdown">
          {slices.map((s) => (
            <li key={s.name} className="flex items-center justify-between gap-3 text-sm">
              <span className="flex items-center gap-2.5 text-slate-300">
                <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
                {s.name}
              </span>
              <span className="num font-semibold text-white">{formatPct(s.pct, { sign: false, digits: 1 })}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
