import { Eye, EyeOff, ShoppingCart } from 'lucide-react';
import { useMemo, useState } from 'react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { SECTOR_COLORS, STOCK_MAP } from '../data/stocks';
import { formatDate, formatINR, formatMarketCap, formatNumber, formatShortDate, toneClass } from '../lib/format';
import { RANGE_DAYS, stockSeries } from '../lib/history';
import { useApp } from '../store/AppContext';
import { heldQuantity } from '../lib/calc';
import { Change, ChartTooltip, DemoBadge, Drawer, Segmented } from './ui';

const RANGES = ['1M', '3M', '6M', '1Y'] as const;

export default function StockDetail({
  symbol,
  onClose,
  onTrade,
}: {
  symbol: string | null;
  onClose: () => void;
  onTrade: (symbol: string, side: 'BUY' | 'SELL') => void;
}) {
  const { quotes, data, toggleWatch } = useApp();
  const [range, setRange] = useState<(typeof RANGES)[number]>('6M');
  const stock = symbol ? STOCK_MAP[symbol] : undefined;
  const quote = symbol ? quotes[symbol] : undefined;

  const series = useMemo(() => (symbol ? stockSeries(symbol, RANGE_DAYS[range], quote?.price) : []), [symbol, range, quote?.price]);

  if (!stock || !quote) return <Drawer open={false} onClose={onClose} title="" children={null} />;

  const change = quote.price - quote.prevClose;
  const changePct = (change / quote.prevClose) * 100;
  const watched = data?.watchlist.includes(stock.symbol) ?? false;
  const held = data ? heldQuantity(data.transactions, stock.symbol) : 0;
  const first = series[0]?.price ?? quote.price;
  const rangePct = ((quote.price - first) / first) * 100;
  const prices = series.map((s) => s.price);
  const high = Math.max(...prices);
  const low = Math.min(...prices);
  const up = rangePct >= 0;
  const stroke = up ? '#34d399' : '#fb7185';

  return (
    <Drawer open={!!symbol} onClose={onClose} title={stock.name}>
      <div className="space-y-6">
        <div>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="rounded-md bg-white/10 px-2 py-0.5 font-semibold text-white">{stock.symbol}</span>
            <span className="rounded-md border border-white/10 px-2 py-0.5 text-slate-300">NSE</span>
            <span className="rounded-md border border-white/10 px-2 py-0.5 text-slate-300">BSE: {stock.bseCode}</span>
            <span className="rounded-md px-2 py-0.5 font-medium" style={{ background: SECTOR_COLORS[stock.sector] + '26', color: '#e2e8f0' }}>
              {stock.sector}
            </span>
          </div>
          <div className="mt-4 flex flex-wrap items-end gap-x-4 gap-y-1">
            <span className="num font-display text-4xl font-semibold text-white">{formatINR(quote.price)}</span>
            <span className={`num pb-1 text-sm font-semibold ${toneClass(change)}`}>
              {change >= 0 ? '+' : '-'}₹{formatNumber(Math.abs(change))} <Change value={changePct} className="ml-1" />
            </span>
          </div>
          <div className="mt-2 flex items-center gap-2 text-xs text-slate-400">
            <DemoBadge /> Sample price. Not a live NSE/BSE quote.
          </div>
        </div>

        <div>
          <div className="mb-3 flex items-center justify-between">
            <span className="text-xs text-slate-400">
              {range} change <Change value={rangePct} />
            </span>
            <Segmented options={RANGES} value={range} onChange={setRange} label="Chart range" />
          </div>
          <div className="h-56 w-full">
            <ResponsiveContainer>
              <AreaChart data={series} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="sd" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={stroke} stopOpacity={0.28} />
                    <stop offset="100%" stopColor={stroke} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis dataKey="date" tickFormatter={formatShortDate} tickLine={false} axisLine={false} minTickGap={36} />
                <YAxis domain={['auto', 'auto']} tickLine={false} axisLine={false} width={52} tickFormatter={(v) => formatNumber(v, 0)} />
                <Tooltip
                  cursor={{ stroke: '#7d8bab', strokeDasharray: '3 3' }}
                  content={<ChartTooltip format={(v) => formatINR(v)} labelFormat={formatDate} />}
                />
                <Area type="monotone" dataKey="price" name="Sample price" stroke={stroke} strokeWidth={2} fill="url(#sd)" dot={false} activeDot={{ r: 4, stroke: '#0f1829', strokeWidth: 2 }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-1 text-[11px] text-slate-500">Sample price history generated for demonstration.</p>
        </div>

        <dl className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
          {[
            ['Previous close', formatINR(quote.prevClose)],
            [`${range} high`, formatINR(high)],
            [`${range} low`, formatINR(low)],
            ['Market cap', formatMarketCap(stock.marketCapCr)],
            ['P/E ratio', formatNumber(stock.pe, 1)],
            ['Dividend yield', `${formatNumber(stock.dividendYield, 1)}%`],
          ].map(([k, v]) => (
            <div key={k} className="rounded-xl border border-white/[0.06] bg-charcoal-800/60 px-3.5 py-3">
              <dt className="text-xs text-slate-400">{k}</dt>
              <dd className="num mt-1 font-semibold text-white">{v}</dd>
            </div>
          ))}
        </dl>
        <p className="-mt-3 text-[11px] text-slate-500">Market cap, P/E and yield are sample figures.</p>

        <div>
          <h4 className="mb-1.5 text-sm font-semibold text-white">About</h4>
          <p className="text-sm leading-relaxed text-slate-400">{stock.about}</p>
        </div>

        {held > 0 && (
          <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/[0.06] px-4 py-3 text-sm text-emerald-200">
            You hold <span className="num font-semibold">{held}</span> share{held === 1 ? '' : 's'} in your virtual portfolio.
          </div>
        )}

        <div className="flex flex-wrap gap-3">
          <button className="btn-primary flex-1" onClick={() => onTrade(stock.symbol, 'BUY')}>
            <ShoppingCart size={16} aria-hidden="true" /> Buy
          </button>
          {held > 0 && (
            <button className="btn-danger flex-1" onClick={() => onTrade(stock.symbol, 'SELL')}>
              Sell
            </button>
          )}
          <button className="btn-ghost flex-1" onClick={() => toggleWatch(stock.symbol)}>
            {watched ? <EyeOff size={16} aria-hidden="true" /> : <Eye size={16} aria-hidden="true" />}
            {watched ? 'Remove from watchlist' : 'Add to watchlist'}
          </button>
        </div>
      </div>
    </Drawer>
  );
}
