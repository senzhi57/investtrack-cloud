import { useMemo, useState } from 'react';
import { Area, AreaChart, CartesianGrid, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { portfolioHistory } from '../lib/calc';
import { formatDate, formatNumber, formatShortDate } from '../lib/format';
import { RANGE_DAYS } from '../lib/history';
import { useApp } from '../store/AppContext';
import { ChartTooltip, Segmented } from './ui';

const RANGES = ['1M', '3M', '6M', '1Y'] as const;
type Range = (typeof RANGES)[number];

export default function PerformanceChart({ height = 300, initial }: { height?: number; initial?: Range }) {
  const { data, quotes, money } = useApp();
  const [range, setRange] = useState<Range>(initial ?? data?.preferences.defaultRange ?? '6M');

  const points = useMemo(
    () => (data ? portfolioHistory(data.transactions, quotes, RANGE_DAYS[range]) : []),
    [data, quotes, range],
  );

  const first = points.find((p) => p.value > 0)?.value ?? 0;
  const last = points[points.length - 1]?.value ?? 0;
  const diff = last - first;

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-4 text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <span className="h-0.5 w-4 rounded bg-emerald-400" /> Portfolio value
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-0.5 w-4 rounded border-t-2 border-dashed border-slate-400" /> Amount invested
          </span>
        </div>
        <Segmented options={RANGES} value={range} onChange={setRange} label="Chart range" />
      </div>
      <div style={{ height }} className="w-full">
        <ResponsiveContainer>
          <AreaChart data={points} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="pv" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#34d399" stopOpacity={0.32} />
                <stop offset="100%" stopColor="#34d399" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
            <XAxis dataKey="date" tickFormatter={formatShortDate} tickLine={false} axisLine={false} minTickGap={40} />
            <YAxis
              tickLine={false}
              axisLine={false}
              width={58}
              domain={['auto', 'auto']}
              tickFormatter={(v: number) => (v >= 1e5 ? `${formatNumber(v / 1e5, 1)}L` : formatNumber(v, 0))}
            />
            <Tooltip
              cursor={{ stroke: '#7d8bab', strokeDasharray: '3 3' }}
              content={<ChartTooltip format={(v) => money(v, { forceFull: true })} labelFormat={formatDate} />}
            />
            <Area type="monotone" dataKey="value" name="Portfolio value" stroke="#34d399" strokeWidth={2} fill="url(#pv)" dot={false} activeDot={{ r: 4, stroke: '#0f1829', strokeWidth: 2 }} />
            <Line type="stepAfter" dataKey="invested" name="Amount invested" stroke="#94a3b8" strokeDasharray="5 4" strokeWidth={1.5} dot={false} activeDot={{ r: 3 }} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      {points.length > 0 && (
        <p className="mt-2 text-xs text-slate-500">
          Value over this period: {diff >= 0 ? 'up' : 'down'} {money(Math.abs(diff), { forceFull: true })}. Built from your transactions and sample (DEMO) prices.
        </p>
      )}
    </div>
  );
}
