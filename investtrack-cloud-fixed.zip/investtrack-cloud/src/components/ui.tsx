import { AlertCircle, CheckCircle2, Info, TrendingDown, TrendingUp, X } from 'lucide-react';
import { useEffect, type ReactNode } from 'react';
import { formatPct, toneClass } from '../lib/format';
import { useApp } from '../store/AppContext';

export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

/* ---------- Brand ---------- */
export function Logo({ size = 34, withText = true }: { size?: number; withText?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
        <rect width="32" height="32" rx="9" fill="#10b981" />
        <path d="M7 21l6-6 4 4 8-9" fill="none" stroke="#0a1224" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="25" cy="10" r="2" fill="#0a1224" />
      </svg>
      {withText && (
        <span className="font-display text-[17px] font-semibold tracking-tight text-white">
          InvestTrack <span className="text-emerald-400">Cloud</span>
        </span>
      )}
    </div>
  );
}

export function DemoBadge({ className }: { className?: string }) {
  return (
    <span
      title="Sample data. Not a live NSE/BSE quote."
      className={cx(
        'inline-flex items-center rounded-md border border-amber-400/30 bg-amber-400/10 px-1.5 py-0.5 text-[10px] font-bold tracking-wide text-amber-300',
        className,
      )}
    >
      DEMO DATA
    </span>
  );
}

/* ---------- Layout bits ---------- */
export function Panel({ children, className, pad = true }: { children: ReactNode; className?: string; pad?: boolean }) {
  return <section className={cx('panel', pad && 'p-5', className)}>{children}</section>;
}

export function PanelHeader({ title, subtitle, action }: { title: string; subtitle?: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h3 className="font-display text-[15px] font-semibold text-white">{title}</h3>
        {subtitle && <p className="mt-0.5 text-xs text-slate-400">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: string; description?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div className="min-w-0">
        <h1 className="font-display text-2xl font-semibold tracking-tight text-white sm:text-[28px]">{title}</h1>
        {description && <p className="mt-1.5 max-w-2xl text-sm text-slate-400">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function StatCard({
  label,
  value,
  sub,
  tone,
  icon,
  accent,
}: {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  tone?: number;
  icon?: ReactNode;
  accent?: boolean;
}) {
  return (
    <div className={cx('panel relative overflow-hidden p-5 transition hover:border-white/10', accent && 'border-emerald-500/25')}>
      {accent && <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-emerald-500/10 blur-2xl" />}
      <div className="flex items-center justify-between text-slate-400">
        <span className="text-[13px] font-medium">{label}</span>
        {icon}
      </div>
      <div className={cx('num mt-3 font-display text-[26px] font-semibold leading-none tracking-tight', tone !== undefined ? toneClass(tone) : 'text-white')}>
        {value}
      </div>
      {sub && <div className="mt-2.5 text-xs text-slate-400">{sub}</div>}
    </div>
  );
}

export function Change({ value, className, showIcon = true }: { value: number; className?: string; showIcon?: boolean }) {
  const Icon = value >= 0 ? TrendingUp : TrendingDown;
  return (
    <span className={cx('num inline-flex items-center gap-1 font-semibold', toneClass(value), className)}>
      {showIcon && value !== 0 && <Icon size={13} aria-hidden="true" />}
      {formatPct(value)}
    </span>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  label,
}: {
  options: readonly T[];
  value: T;
  onChange: (v: T) => void;
  label: string;
}) {
  return (
    <div role="tablist" aria-label={label} className="inline-flex rounded-xl border border-white/10 bg-navy-950/60 p-0.5">
      {options.map((o) => (
        <button
          key={o}
          role="tab"
          aria-selected={o === value}
          onClick={() => onChange(o)}
          className={cx(
            'rounded-lg px-3 py-1.5 text-xs font-semibold transition',
            o === value ? 'bg-emerald-500 text-navy-950' : 'text-slate-400 hover:text-white',
          )}
        >
          {o}
        </button>
      ))}
    </div>
  );
}

/* ---------- Forms ---------- */
export function Field({
  label,
  error,
  hint,
  children,
  htmlFor,
}: {
  label: string;
  error?: string;
  hint?: string;
  children: ReactNode;
  htmlFor?: string;
}) {
  return (
    <div>
      <label htmlFor={htmlFor} className="mb-1.5 block text-[13px] font-medium text-slate-300">
        {label}
      </label>
      {children}
      {error ? (
        <p role="alert" className="mt-1.5 flex items-center gap-1.5 text-xs text-loss-400">
          <AlertCircle size={13} aria-hidden="true" />
          {error}
        </p>
      ) : (
        hint && <p className="mt-1.5 text-xs text-slate-500">{hint}</p>
      )}
    </div>
  );
}

export function ErrorBanner({ message }: { message?: string }) {
  if (!message) return null;
  return (
    <div role="alert" className="flex items-start gap-2.5 rounded-xl border border-loss-500/30 bg-loss-500/10 px-3.5 py-3 text-sm text-loss-400">
      <AlertCircle size={16} className="mt-0.5 shrink-0" aria-hidden="true" />
      <span>{message}</span>
    </div>
  );
}

/* ---------- Overlays ---------- */
export function Modal({
  open,
  onClose,
  title,
  children,
  width = 'max-w-lg',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  width?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 animate-fade bg-navy-950/80 backdrop-blur-sm" onClick={onClose} />
      <div className={cx('relative max-h-[92vh] w-full animate-pop overflow-y-auto rounded-t-3xl border border-white/10 bg-navy-800 p-6 shadow-2xl sm:rounded-3xl', width)}>
        <div className="mb-5 flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold text-white">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="rounded-lg p-1.5 text-slate-400 transition hover:bg-white/10 hover:text-white">
            <X size={18} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Drawer({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 animate-fade bg-navy-950/70 backdrop-blur-sm" onClick={onClose} />
      <aside className="absolute right-0 top-0 h-full w-full max-w-xl animate-slide overflow-y-auto border-l border-white/10 bg-navy-850 p-6 shadow-2xl">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold text-white">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="rounded-lg p-1.5 text-slate-400 transition hover:bg-white/10 hover:text-white">
            <X size={18} />
          </button>
        </div>
        {children}
      </aside>
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon: ReactNode;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-white/10 px-6 py-14 text-center">
      <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-400">{icon}</div>
      <h3 className="font-display text-base font-semibold text-white">{title}</h3>
      <p className="mt-1.5 max-w-sm text-sm text-slate-400">{description}</p>
      {action && <div className="mt-5 flex flex-wrap justify-center gap-2">{action}</div>}
    </div>
  );
}

export function Toasts() {
  const { toasts, dismissToast } = useApp();
  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-[min(92vw,380px)] flex-col gap-2" aria-live="polite">
      {toasts.map((t) => {
        const Icon = t.kind === 'success' ? CheckCircle2 : t.kind === 'error' ? AlertCircle : Info;
        const tone = t.kind === 'success' ? 'text-emerald-400' : t.kind === 'error' ? 'text-loss-400' : 'text-sky-300';
        return (
          <div key={t.id} className="pointer-events-auto flex animate-pop items-start gap-3 rounded-xl border border-white/10 bg-navy-700 px-4 py-3 text-sm text-slate-100 shadow-2xl">
            <Icon size={17} className={cx('mt-0.5 shrink-0', tone)} aria-hidden="true" />
            <span className="flex-1">{t.message}</span>
            <button onClick={() => dismissToast(t.id)} aria-label="Dismiss" className="text-slate-400 hover:text-white">
              <X size={15} />
            </button>
          </div>
        );
      })}
    </div>
  );
}

/* ---------- Charts ---------- */
interface TipRow {
  name?: string;
  value?: number | string;
  color?: string;
  payload?: Record<string, unknown>;
}
export function ChartTooltip({
  active,
  payload,
  label,
  format,
  labelFormat,
}: {
  active?: boolean;
  payload?: TipRow[];
  label?: string | number;
  format?: (v: number, name?: string) => string;
  labelFormat?: (l: string) => string;
}) {
  if (!active || !payload || payload.length === 0) return null;
  const title = label !== undefined ? (labelFormat ? labelFormat(String(label)) : String(label)) : payload[0].name;
  return (
    <div className="min-w-[150px] rounded-xl border border-white/10 bg-navy-700/95 px-3.5 py-2.5 text-xs shadow-2xl backdrop-blur">
      {title && <div className="mb-1.5 font-semibold text-white">{title}</div>}
      <div className="space-y-1">
        {payload.map((p, i) => (
          <div key={i} className="flex items-center justify-between gap-4">
            <span className="flex items-center gap-1.5 text-slate-300">
              <span className="h-2 w-2 rounded-full" style={{ background: p.color }} />
              {p.name}
            </span>
            <span className="num font-semibold text-white">{format ? format(Number(p.value), p.name) : String(p.value)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Sparkline({ values, positive }: { values: number[]; positive: boolean }) {
  if (values.length < 2) return null;
  const w = 120;
  const h = 36;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const pts = values.map((v, i) => `${(i / (values.length - 1)) * w},${h - 3 - ((v - min) / span) * (h - 6)}`).join(' ');
  const color = positive ? '#34d399' : '#fb7185';
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} aria-hidden="true" className="overflow-visible">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
