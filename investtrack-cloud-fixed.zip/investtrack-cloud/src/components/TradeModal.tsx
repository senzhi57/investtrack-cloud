import { useEffect, useMemo, useState } from 'react';
import { STOCKS, STOCK_MAP } from '../data/stocks';
import { heldQuantity } from '../lib/calc';
import { formatINR, roundTo, todayISO } from '../lib/format';
import { useApp } from '../store/AppContext';
import type { Exchange, Side, ValidationResult } from '../types';
import { cx, DemoBadge, ErrorBanner, Field, Modal } from './ui';

export interface TradeRequest {
  symbol?: string;
  side?: Side;
}

export default function TradeModal({ open, onClose, request }: { open: boolean; onClose: () => void; request: TradeRequest }) {
  const { data, quotes, placeOrder, summary } = useApp();
  const [side, setSide] = useState<Side>('BUY');
  const [symbol, setSymbol] = useState('');
  const [exchange, setExchange] = useState<Exchange>('NSE');
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState('');
  const [date, setDate] = useState(todayISO());
  const [result, setResult] = useState<ValidationResult | null>(null);
  const [busy, setBusy] = useState(false);

  // Reset the form every time the modal opens
  useEffect(() => {
    if (!open) return;
    const sym = request.symbol ?? '';
    setSide(request.side ?? 'BUY');
    setSymbol(sym);
    setExchange(data?.preferences.defaultExchange ?? 'NSE');
    setQuantity('');
    setPrice(sym && quotes[sym] ? String(quotes[sym].price) : '');
    setDate(todayISO());
    setResult(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, request.symbol, request.side]);

  const held = useMemo(() => (symbol && data ? heldQuantity(data.transactions, symbol) : 0), [symbol, data]);
  const qtyNum = Number(quantity);
  const priceNum = Number(price);
  const total = Number.isFinite(qtyNum) && Number.isFinite(priceNum) ? roundTo(qtyNum * priceNum) : 0;
  const errors = result?.errors ?? {};

  const pickSymbol = (s: string) => {
    setSymbol(s);
    if (s && quotes[s]) setPrice(String(quotes[s].price));
    setResult(null);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const res = await placeOrder({ symbol, side, exchange, quantity: qtyNum, price: priceNum, date });
    setBusy(false);
    if (res.ok) onClose();
    else setResult(res);
  };

  const stock = symbol ? STOCK_MAP[symbol] : undefined;
  const marketPrice = symbol ? quotes[symbol]?.price : undefined;

  return (
    <Modal open={open} onClose={onClose} title={side === 'BUY' ? 'Record a virtual purchase' : 'Record a virtual sale'}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <div className="grid grid-cols-2 gap-1 rounded-xl border border-white/10 bg-navy-950/60 p-1" role="group" aria-label="Order side">
          {(['BUY', 'SELL'] as Side[]).map((s) => (
            <button
              type="button"
              key={s}
              onClick={() => {
                setSide(s);
                setResult(null);
              }}
              className={cx(
                'rounded-lg py-2 text-sm font-semibold transition',
                side === s ? (s === 'BUY' ? 'bg-emerald-500 text-navy-950' : 'bg-loss-500 text-white') : 'text-slate-400 hover:text-white',
              )}
            >
              {s === 'BUY' ? 'Buy' : 'Sell'}
            </button>
          ))}
        </div>

        <Field label="Stock" htmlFor="t-symbol" error={errors.symbol}>
          <select id="t-symbol" className={cx('input', errors.symbol && 'input-error')} value={symbol} onChange={(e) => pickSymbol(e.target.value)}>
            <option value="">Select a stock</option>
            {STOCKS.map((s) => (
              <option key={s.symbol} value={s.symbol}>
                {s.symbol} · {s.name}
              </option>
            ))}
          </select>
        </Field>

        {stock && (
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-charcoal-800/70 px-3.5 py-2.5 text-xs text-slate-300">
            <span>
              Sample price <span className="num font-semibold text-white">{formatINR(marketPrice ?? stock.basePrice)}</span>
            </span>
            <DemoBadge />
            <span>
              You hold <span className="num font-semibold text-white">{held}</span> share{held === 1 ? '' : 's'}
            </span>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <Field label="Quantity" htmlFor="t-qty" error={errors.quantity}>
            <input
              id="t-qty"
              inputMode="numeric"
              className={cx('input num', errors.quantity && 'input-error')}
              placeholder="e.g. 10"
              value={quantity}
              onChange={(e) => {
                setQuantity(e.target.value);
                setResult(null);
              }}
            />
          </Field>
          <Field label={side === 'BUY' ? 'Purchase price (₹)' : 'Sale price (₹)'} htmlFor="t-price" error={errors.price}>
            <input
              id="t-price"
              inputMode="decimal"
              className={cx('input num', errors.price && 'input-error')}
              placeholder="0.00"
              value={price}
              onChange={(e) => {
                setPrice(e.target.value);
                setResult(null);
              }}
            />
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Date" htmlFor="t-date" error={errors.date}>
            <input
              id="t-date"
              type="date"
              max={todayISO()}
              className={cx('input', errors.date && 'input-error')}
              value={date}
              onChange={(e) => {
                setDate(e.target.value);
                setResult(null);
              }}
            />
          </Field>
          <Field label="Exchange" htmlFor="t-ex">
            <select id="t-ex" className="input" value={exchange} onChange={(e) => setExchange(e.target.value as Exchange)}>
              <option value="NSE">NSE</option>
              <option value="BSE">BSE</option>
            </select>
          </Field>
        </div>

        <div className="flex items-center justify-between rounded-xl border border-white/[0.06] bg-navy-950/50 px-4 py-3 text-sm">
          <span className="text-slate-400">Order value</span>
          <span className="num font-display text-lg font-semibold text-white">{formatINR(total)}</span>
        </div>
        <div className="flex items-center justify-between px-1 text-xs text-slate-500">
          <span>Virtual cash available</span>
          <span className="num">{formatINR(summary.cash)}</span>
        </div>

        <ErrorBanner message={errors.form} />

        <div className="flex gap-3 pt-1">
          <button type="button" onClick={onClose} className="btn-ghost flex-1">
            Cancel
          </button>
          <button type="submit" disabled={busy} className={cx('flex-1', side === 'BUY' ? 'btn-primary' : 'btn bg-loss-500 text-white hover:bg-loss-400')}>
            {side === 'BUY' ? 'Record purchase' : 'Record sale'}
          </button>
        </div>
        <p className="text-center text-[11px] text-slate-500">Virtual transaction only. Nothing is sent to NSE, BSE or any broker.</p>
      </form>
    </Modal>
  );
}
