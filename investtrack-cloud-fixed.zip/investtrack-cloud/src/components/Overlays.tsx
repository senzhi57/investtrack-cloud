import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import type { Side } from '../types';
import StockDetail from './StockDetail';
import TradeModal, { type TradeRequest } from './TradeModal';

interface OverlayApi {
  openTrade: (symbol?: string, side?: Side) => void;
  openDetail: (symbol: string) => void;
}

const Ctx = createContext<OverlayApi | null>(null);

/** Hosts the shared trade form and stock detail drawer so any page can open them. */
export function OverlayProvider({ children }: { children: ReactNode }) {
  const [trade, setTrade] = useState<{ open: boolean; req: TradeRequest }>({ open: false, req: {} });
  const [detail, setDetail] = useState<string | null>(null);

  const openTrade = useCallback((symbol?: string, side?: Side) => {
    setDetail(null);
    setTrade({ open: true, req: { symbol, side } });
  }, []);
  const openDetail = useCallback((symbol: string) => setDetail(symbol), []);

  const api = useMemo(() => ({ openTrade, openDetail }), [openTrade, openDetail]);

  return (
    <Ctx.Provider value={api}>
      {children}
      <TradeModal open={trade.open} request={trade.req} onClose={() => setTrade((t) => ({ ...t, open: false }))} />
      <StockDetail symbol={detail} onClose={() => setDetail(null)} onTrade={(s, side) => openTrade(s, side)} />
    </Ctx.Provider>
  );
}

export function useOverlays(): OverlayApi {
  const v = useContext(Ctx);
  if (!v) throw new Error('useOverlays must be used inside <OverlayProvider>');
  return v;
}
