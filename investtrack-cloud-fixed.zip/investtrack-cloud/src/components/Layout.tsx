import {
  BarChart3,
  Eye,
  History,
  LayoutDashboard,
  LineChart,
  LogOut,
  Menu,
  RefreshCw,
  Settings,
  Wallet,
  X,
} from 'lucide-react';
import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useApp } from '../store/AppContext';
import { DEMO_NOTICE } from '../data/stocks';
import { OverlayProvider } from './Overlays';
import { cx, DemoBadge, Logo, Toasts } from './ui';

const NAV = [
  { to: '/app', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/app/explorer', label: 'Stock Explorer', icon: LineChart },
  { to: '/app/portfolio', label: 'My Portfolio', icon: Wallet },
  { to: '/app/watchlist', label: 'Watchlist', icon: Eye },
  { to: '/app/transactions', label: 'Transactions', icon: History },
  { to: '/app/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/app/settings', label: 'Profile & Settings', icon: Settings },
];

export default function Layout() {
  const { user, data, logout, simulateMarket, money, summary } = useApp();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const doLogout = async () => {
    await logout();
    navigate('/');
  };

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="px-5 pb-6 pt-6">
        <Logo />
      </div>
      <nav className="flex-1 space-y-1 px-3" aria-label="Main">
        {NAV.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            onClick={() => setOpen(false)}
            className={({ isActive }) =>
              cx(
                'group flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition',
                isActive ? 'bg-emerald-500/[0.12] text-emerald-300 shadow-[inset_2px_0_0_#10b981]' : 'text-slate-400 hover:bg-white/5 hover:text-white',
              )
            }
          >
            <Icon size={18} aria-hidden="true" />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="space-y-3 p-4">
        <div className="rounded-2xl border border-white/[0.06] bg-charcoal-800/80 p-4">
          <div className="text-xs text-slate-400">Virtual cash</div>
          <div className="num mt-1 font-display text-lg font-semibold text-white">{money(summary.cash, { forceFull: true })}</div>
          <div className="mt-1 text-[11px] text-slate-500">Practice money. No real funds.</div>
        </div>
        <div className="flex items-center gap-3 rounded-2xl border border-white/[0.06] bg-charcoal-800/80 p-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-sm font-bold text-emerald-300">
            {(data?.profile.name || user?.name || 'U').charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-semibold text-white">{data?.profile.name || user?.name}</div>
            <div className="truncate text-[11px] text-slate-500">{user?.email}</div>
          </div>
          <button onClick={doLogout} aria-label="Log out" title="Log out" className="rounded-lg p-2 text-slate-400 transition hover:bg-white/10 hover:text-white">
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-white/[0.06] bg-navy-950/85 backdrop-blur lg:block">{sidebar}</aside>

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 animate-fade bg-navy-950/80" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 animate-slide border-r border-white/10 bg-navy-900" style={{ animationName: 'fade' }}>
            <button onClick={() => setOpen(false)} aria-label="Close menu" className="absolute right-3 top-4 rounded-lg p-2 text-slate-400 hover:bg-white/10">
              <X size={18} />
            </button>
            {sidebar}
          </aside>
        </div>
      )}

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-white/[0.06] bg-navy-900/80 px-4 py-3 backdrop-blur-md sm:px-8">
          <button onClick={() => setOpen(true)} aria-label="Open menu" className="rounded-lg p-2 text-slate-300 hover:bg-white/10 lg:hidden">
            <Menu size={20} />
          </button>
          <div className="lg:hidden">
            <Logo size={28} withText={false} />
          </div>
          <div className="ml-auto flex items-center gap-2.5">
            <DemoBadge className="hidden sm:inline-flex" />
            <button onClick={simulateMarket} className="btn-ghost !px-3 !py-2 text-xs" title="Randomly nudges the demo prices to show how every metric recalculates">
              <RefreshCw size={14} aria-hidden="true" />
              <span className="hidden sm:inline">Simulate demo market move</span>
              <span className="sm:hidden">Simulate</span>
            </button>
          </div>
        </header>

        {data?.preferences.showDemoBanner && (
          <div className="border-b border-amber-400/15 bg-amber-400/[0.06] px-4 py-2 text-center text-xs text-amber-200/90 sm:px-8">{DEMO_NOTICE}</div>
        )}

        <OverlayProvider>
          <main className="mx-auto w-full max-w-[1400px] px-4 py-6 sm:px-8 sm:py-8">
            <Outlet />
          </main>
        </OverlayProvider>
      </div>
      <Toasts />
    </div>
  );
}
