import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { computeSummary, validateOrder } from '../lib/calc';
import { formatINR } from '../lib/format';
import { ServiceError, services } from '../services';
import type {
  OrderInput,
  PortfolioSummary,
  Preferences,
  QuoteMap,
  SessionUser,
  UserData,
  UserProfile,
  ValidationResult,
} from '../types';

export interface Toast {
  id: number;
  kind: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextValue {
  booting: boolean;
  user: SessionUser | null;
  data: UserData | null;
  quotes: QuoteMap;
  summary: PortfolioSummary;
  toasts: Toast[];
  dismissToast: (id: number) => void;
  notify: (kind: Toast['kind'], message: string) => void;
  money: (value: number, opts?: { sign?: boolean; forceFull?: boolean }) => string;

  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  loginDemo: () => Promise<void>;
  logout: () => Promise<void>;

  placeOrder: (order: OrderInput) => Promise<ValidationResult>;
  toggleWatch: (symbol: string) => Promise<void>;
  removeWatch: (symbol: string) => Promise<void>;
  addWatch: (symbol: string) => Promise<void>;
  saveProfile: (profile: UserProfile) => Promise<void>;
  savePreferences: (prefs: Preferences) => Promise<void>;
  simulateMarket: () => Promise<void>;
  resetPrices: () => Promise<void>;
  resetData: (mode: 'sample' | 'empty', startingCapital?: number) => Promise<void>;
}

const Ctx = createContext<AppContextValue | null>(null);

const EMPTY_SUMMARY: PortfolioSummary = {
  holdings: [],
  invested: 0,
  currentValue: 0,
  unrealizedPnl: 0,
  unrealizedPnlPct: 0,
  realizedPnl: 0,
  totalPnl: 0,
  totalPnlPct: 0,
  dayChange: 0,
  dayChangePct: 0,
  cash: 0,
  netWorth: 0,
};

export function AppProvider({ children }: { children: ReactNode }) {
  const [booting, setBooting] = useState(true);
  const [user, setUser] = useState<SessionUser | null>(null);
  const [data, setData] = useState<UserData | null>(null);
  const [quotes, setQuotes] = useState<QuoteMap>({});
  const [toasts, setToasts] = useState<Toast[]>([]);
  const toastId = useRef(0);

  const dismissToast = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);
  const notify = useCallback((kind: Toast['kind'], message: string) => {
    const id = ++toastId.current;
    setToasts((t) => [...t.slice(-3), { id, kind, message }]);
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4500);
  }, []);

  const enter = useCallback(async (u: SessionUser) => {
    const [d, q] = await Promise.all([services.portfolio.load(u), services.market.getQuotes()]);
    setUser(u);
    setData(d);
    setQuotes(q);
  }, []);

  // Restore session on first load
  useEffect(() => {
    (async () => {
      try {
        const s = await services.auth.getSession();
        if (s) await enter(s);
        else setQuotes(await services.market.getQuotes());
      } catch {
        /* start logged out */
      } finally {
        setBooting(false);
      }
    })();
  }, [enter]);

  const summary = useMemo(
    () => (data ? computeSummary(data.transactions, quotes, data.preferences.startingCapital) : EMPTY_SUMMARY),
    [data, quotes],
  );

  const compact = data?.preferences.numberFormat === 'compact';
  const money = useCallback(
    (value: number, opts: { sign?: boolean; forceFull?: boolean } = {}) =>
      formatINR(value, { compact: compact && !opts.forceFull, sign: opts.sign }),
    [compact],
  );

  const errMsg = (e: unknown) => (e instanceof ServiceError || e instanceof Error ? e.message : 'Something went wrong. Try again.');

  const login = useCallback(
    async (email: string, password: string) => {
      const u = await services.auth.login(email, password);
      await enter(u);
    },
    [enter],
  );
  const register = useCallback(
    async (name: string, email: string, password: string) => {
      const u = await services.auth.register(name, email, password);
      await enter(u);
    },
    [enter],
  );
  const loginDemo = useCallback(async () => {
    const u = await services.auth.loginDemo();
    await enter(u);
  }, [enter]);
  const logout = useCallback(async () => {
    await services.auth.logout();
    setUser(null);
    setData(null);
  }, []);

  const placeOrder = useCallback(
    async (order: OrderInput): Promise<ValidationResult> => {
      if (!user || !data) return { ok: false, errors: { form: 'You are logged out. Log in to place virtual orders.' } };
      const check = validateOrder(order, data.transactions, data.preferences.startingCapital);
      if (!check.ok) return check;
      try {
        const txn = await services.portfolio.addTransaction(user.id, order);
        setData((d) => (d ? { ...d, transactions: [...d.transactions, txn] } : d));
        notify(
          'success',
          `${order.side === 'BUY' ? 'Bought' : 'Sold'} ${order.quantity} ${order.symbol} at ${formatINR(order.price)} (virtual)`,
        );
        return { ok: true, errors: {} };
      } catch (e) {
        return { ok: false, errors: { form: errMsg(e) } };
      }
    },
    [user, data, notify],
  );

  const addWatch = useCallback(
    async (symbol: string) => {
      if (!user) return;
      try {
        const watchlist = await services.portfolio.addToWatchlist(user.id, symbol);
        setData((d) => (d ? { ...d, watchlist } : d));
        notify('success', `${symbol} added to your watchlist`);
      } catch (e) {
        notify('error', errMsg(e));
      }
    },
    [user, notify],
  );

  const removeWatch = useCallback(
    async (symbol: string) => {
      if (!user) return;
      try {
        const watchlist = await services.portfolio.removeFromWatchlist(user.id, symbol);
        setData((d) => (d ? { ...d, watchlist } : d));
        notify('info', `${symbol} removed from your watchlist`);
      } catch (e) {
        notify('error', errMsg(e));
      }
    },
    [user, notify],
  );

  const toggleWatch = useCallback(
    async (symbol: string) => {
      if (data?.watchlist.includes(symbol)) await removeWatch(symbol);
      else await addWatch(symbol);
    },
    [data, addWatch, removeWatch],
  );

  const saveProfile = useCallback(
    async (profile: UserProfile) => {
      if (!user) return;
      const saved = await services.portfolio.updateProfile(user.id, profile);
      setData((d) => (d ? { ...d, profile: saved } : d));
      notify('success', 'Profile saved');
    },
    [user, notify],
  );

  const savePreferences = useCallback(
    async (prefs: Preferences) => {
      if (!user) return;
      const saved = await services.portfolio.updatePreferences(user.id, prefs);
      setData((d) => (d ? { ...d, preferences: saved } : d));
      notify('success', 'Preferences saved');
    },
    [user, notify],
  );

  const simulateMarket = useCallback(async () => {
    setQuotes(await services.market.simulateTick());
    notify('info', 'Demo prices moved. Every figure has been recalculated.');
  }, [notify]);

  const resetPrices = useCallback(async () => {
    setQuotes(await services.market.resetQuotes());
    notify('info', 'Demo prices restored to the sample values');
  }, [notify]);

  const resetData = useCallback(
    async (mode: 'sample' | 'empty', startingCapital?: number) => {
      if (!user) return;
      const fresh = await services.portfolio.reset(user, mode, startingCapital);
      setData(fresh);
      notify('success', mode === 'sample' ? 'Sample portfolio loaded' : 'Portfolio cleared');
    },
    [user, notify],
  );

  const value: AppContextValue = {
    booting,
    user,
    data,
    quotes,
    summary,
    toasts,
    dismissToast,
    notify,
    money,
    login,
    register,
    loginDemo,
    logout,
    placeOrder,
    toggleWatch,
    removeWatch,
    addWatch,
    saveProfile,
    savePreferences,
    simulateMarket,
    resetPrices,
    resetData,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppContextValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useApp must be used inside <AppProvider>');
  return v;
}
