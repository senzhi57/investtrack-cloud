# AWS integration plan for InvestTrack Cloud

**Status: not connected.** This build runs entirely in the browser and stores data in `localStorage`.
There is no AWS code, no AWS SDK and no cloud calls. This document describes how the existing service
layer is meant to be swapped for AWS services later.

## Where the seam is

```
src/services/
  types.ts        <- contracts: AuthService, PortfolioService, MarketService
  index.ts        <- the ONE place that picks the backend
  local/          <- current localStorage implementations
  aws/            <- (future) Cognito + API Gateway/Lambda + DynamoDB implementations
```

Pages and components import only `useApp()` from `src/store/AppContext.tsx`, which calls `services.*`.
To go live, implement the interfaces in `src/services/aws/` and change `src/services/index.ts`.

## Planned mapping

| Concern | Now (local) | Future AWS service |
|---|---|---|
| Sign up / login / session | `local/auth.ts` | Amazon Cognito User Pool (JWT tokens, hosted UI or Amplify Auth) |
| Portfolio and watchlist API | `local/portfolio.ts` | Amazon API Gateway (REST, Cognito authorizer) -> AWS Lambda |
| Persistence | `localStorage` | Amazon DynamoDB |
| Demo market data | `local/market.ts` + `src/data/stocks.ts` | Lambda serving demo data (or a licensed data provider) |
| Static hosting | `npm run build` output in `dist/` | Amazon S3 + CloudFront |

## Proposed API routes (all require a Cognito JWT)

| Method | Route | Lambda responsibility |
|---|---|---|
| GET | `/me` | Return profile and preferences |
| PUT | `/me/profile` | Update profile |
| PUT | `/me/preferences` | Update preferences |
| GET | `/transactions` | List the user's transactions |
| POST | `/transactions` | Validate and store a virtual BUY or SELL |
| GET | `/watchlist` | List watchlist symbols |
| PUT | `/watchlist/{symbol}` | Add a symbol |
| DELETE | `/watchlist/{symbol}` | Remove a symbol |
| GET | `/quotes` | Return demo quotes |

`POST /transactions` **must** repeat the checks in `src/lib/calc.ts -> validateOrder`
(positive integer quantity, positive price, date not in the future, no negative holdings, no negative cash).
Never trust the browser.

## Proposed DynamoDB tables

**InvestTrack-Users**
- PK `userId` (Cognito `sub`)
- attributes: `name`, `email`, `institution`, `investorType`, `preferences` (map), `createdAt`

**InvestTrack-Transactions**
- PK `userId`, SK `date#txnId` (sorts chronologically)
- attributes: `symbol`, `side`, `exchange`, `quantity`, `price`, `createdAt`

**InvestTrack-Watchlist**
- PK `userId`, SK `symbol`
- attributes: `addedAt`

Holdings, average price and P/L are **derived** by replaying transactions (`computeSummary` in
`src/lib/calc.ts`). They can be computed in the browser, or in a Lambda if you prefer to return summaries.

## Suggested order of work

1. Create a Cognito User Pool + app client, then implement `AuthService`.
2. Create the DynamoDB tables and a Lambda per route behind API Gateway with a Cognito authorizer.
3. Implement `PortfolioService` with `fetch` calls to the API and the Cognito ID token.
4. Switch `src/services/index.ts` to the AWS implementations, using an env flag such as `VITE_BACKEND`.
5. Host `dist/` on S3 behind CloudFront. The app uses `HashRouter`, so no rewrite rules are needed.

## Important

Stock prices in this project are sample **DEMO DATA**. They are not live NSE/BSE quotes. If you later add
real market data, use a licensed provider and review its terms for display and redistribution.
