/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Dark navy page + panel surfaces
        navy: {
          950: '#070d19',
          900: '#0a1224',
          850: '#0d1629',
          800: '#0f1829',
          700: '#16223a',
          600: '#1d2c4a',
          500: '#2a3b5e',
        },
        // Charcoal secondary surfaces
        charcoal: {
          900: '#12161d',
          800: '#171c25',
          700: '#1f2531',
          600: '#2a3140',
        },
        emerald: {
          300: '#6ee7b7',
          400: '#34d399',
          500: '#10b981',
          600: '#059669',
          700: '#047857',
        },
        loss: { 400: '#fb7185', 500: '#f43f5e' },
      },
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        display: ['Sora', '"Plus Jakarta Sans"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        panel: '0 1px 0 0 rgba(255,255,255,0.03) inset, 0 12px 32px -16px rgba(0,0,0,0.6)',
        glow: '0 0 0 1px rgba(16,185,129,0.35), 0 8px 30px -8px rgba(16,185,129,0.35)',
      },
      keyframes: {
        pop: { '0%': { opacity: 0, transform: 'translateY(6px) scale(.98)' }, '100%': { opacity: 1, transform: 'none' } },
        fade: { '0%': { opacity: 0 }, '100%': { opacity: 1 } },
        slide: { '0%': { transform: 'translateX(100%)' }, '100%': { transform: 'none' } },
      },
      animation: {
        pop: 'pop .18s ease-out',
        fade: 'fade .18s ease-out',
        slide: 'slide .22s cubic-bezier(.2,.8,.2,1)',
      },
    },
  },
  plugins: [],
};
